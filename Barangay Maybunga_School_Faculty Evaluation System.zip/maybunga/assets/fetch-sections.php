<?php

	session_start();

	include('../global/model.php');
	$model = new Model();

	$data = null;

	$rows = $model->displaySectionsSelection($_POST['year_id'], 1);

	if ($rows[0] != 'No result') {
		if (!empty($rows)) {
			foreach ($rows as $row) {
				$data[] = [$row['section_id'], $row['section_name']];
			}
		}
	}

	else {
		$data[] = 'No result';
	}

	// $result = substr($data, 0, -2);

	echo json_encode($data);

?>