<?php
	session_start(); 
	include('../global/model.php');
	include('department.php');

	if ($status_of == 1) {
		echo "<script>window.open('no-preview','_self');</script>";
	}
	else {

	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">

		<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'subjects';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head">Subjects<span></span></h2>
				</div>	
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<div class="orders-list">
								<h4><?php echo strtoupper($csy); ?> | <?php echo strtoupper($csm); ?></h4><hr>
								<?php
									$previous_rows = $model->displaySubjectsFiltered(1, $year);
									if (!empty($previous_rows)) { 
										foreach ($previous_rows as $row) {

										$photox = "default";
										$name = "";
										$evaluation = '<center><a href="" class="btn button-sm red">Form Unavailable</a></center> ';
										$modal = '';

										$rowsy = $model->displaySubjectInstructor($row['subject_id'], $section_idd, $csid);
										if (!empty($rowsy)) {

											foreach ($rowsy as $rowy) {
												$instructor_subject_id = $rowy['aid'];
												$instructor_id = $rowy['instructor_id'];
												$i_fname = strtoupper($rowy['fname']);
												$i_mname = strtoupper($rowy['mname']);
												$i_lname = strtoupper($rowy['lname']);
												$i_email = strtolower($rowy['email']);
												$i_college = $rowy['college'];
												$i_contact = $rowy['contact'];

												if ($rowy['photo'] == "") {
													$photox = "default";
												}
												else {
													$photox = $rowy['photo'];
												}

												$name = "".$i_fname." ".$i_lname."";
												$evaluation = '<a href="evaluate?id='.$rowy['aid'].'&subject='.$row['subject_id'].'" class="btn button-sm yellow">Evaluate Instructor</a>';
												$modal = 'data-toggle="modal"';

												// echo $account_id;
												// echo "hr";
												// echo $instructor_id;
												// echo "hr";
												// echo $instructor_subject_id;

												$rowsyx = $model->evaluatedChecker($account_id, $instructor_id, $instructor_subject_id);
												if (!empty($rowsyx)) {
													foreach ($rowsyx as $rowyx) {
														$evaluation = '<center><a href="" class="btn button-sm green">Evaluation Finished</a></center> ';
														$modal = 'data-toggle="modal"';
													}
												}

											}
										}
									
										if ($name == "") { $name = "NO INSTRUCTOR PROFILE"; }
								?>
								<ul>
									<li>
										<span class="orders-title">
											<h4><?php echo $row['subject_code']; ?> | <?php echo $row['subject_title']; ?><br><small><a href="" <?php echo $modal; ?> data-target="#profile-<?php echo $row['subject_id']; ?>"><img src="../assets/images/profile-img/<?php echo $photox; ?>.jpg" alt="User" style="width: 30px; height: 30px; border-radius: 50%;object-fit: cover;">&nbsp;<?php echo ucwords(strtolower($name)); ?></a></small></h4>
										</span>
										<span class="orders-btn">
											<center><?php echo $evaluation; ?></center> 
										</span>
									</li>
								</ul><br>

											<div id="profile-<?php echo $row['subject_id']; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Faculty Profile</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																	<input type="hidden" name="user_id" value="<?php echo $uid; ?>">
																	<div class="col-lg-1"></div>
																	<div class="col-lg-10">
																		<center><img src="../assets/images/profile-img/<?php echo $photox; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																		<h4><?php echo ucwords(strtolower($i_fname)); ?> <?php echo ucwords(strtolower($i_mname)); ?> <?php echo ucwords(strtolower($i_lname)); ?></h4>
																		<h6><?php echo $i_college; ?></h6>
																		<h6><?php echo $i_contact; ?></h6>
																		<h6><?php echo $i_email; ?></h6>
																		</center>
																	</div>
																</div>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
								<?php 
										}
									}
									else {
										echo "NO DATA";
									}
								?>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>   
		<script src="../dashboard/assets/js/jquery.dataTables.min.js"></script>
		<script src="../dashboard/assets/js/dataTables.bootstrap4.min.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$('#table').DataTable();
			});

			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
		<script type="text/javascript">
			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z. ]+$/ 
					return re.test(keyChar); 
				} 
			}

			function isNumber(evt) {
				evt = (evt) ? evt : window.event;
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode > 31 && (charCode < 48 || charCode > 57)) {
					return false;
				}
				return true;
			}
		</script>
	</body>

</html>