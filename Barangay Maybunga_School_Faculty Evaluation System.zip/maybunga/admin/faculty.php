<?php
	session_start(); 
	include('../global/model.php');
	include('department.php');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">

		<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'faculty';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head">Teacher<span> Accounts</span></h2>
				</div>	
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<a href="" data-toggle="modal" data-target="#add-faculty" class="btn green radius-xl" style="float: right;"><i class="fa fa-user" style="font-size: 14px;"></i><span>&nbsp;&nbsp;ADD TEACHER ACCOUNT</span></a>
								<br><br>
								<form method="POST">
									<div class="row">
										<div class="col-lg-3">
										</div>
										<div class="col-lg-5">
											<select class="form-control" name="search_dpt" required>
												<option value="all">All Department</option>
												<?php
													$rows = $model->fetchDepartments();

													if (!empty($rows)) {
														foreach ($rows as $row) {
															$dept_name = $row['dept_name'];
												?>
															<option value="<?php echo $dept_name; ?>" <?php echo (isset($_POST['search_dpt']) && $_POST['search_dpt'] == $dept_name) ? 'selected' : ''; ?>><?php echo $dept_name; ?></option>
												<?php
														}
													}
												?>
											</select>
										</div>
										<div class="col-lg-2">
											<button type="submit" name="search_department" class="btn yellow radius-xl">
												<i class="ti-search"></i>
												<span>&nbsp;&nbsp;SEARCH</span>
											</button>
										</div>
										<div class="col-lg-3">
										</div>
									</div>
								</form>
								<br><br>
								<div class="table-responsive">
									<table id="table" class="table hover" style="width:100%">
										<thead>
											<tr>
												<th width="100">School ID</th>
												<th width="250">Name</th>
												<th>Email</th>
												<th>Department</th>
												<!-- <th width="80">Status</th> -->
												<th width="100">Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$access = 1;
											$status = 2;
											$rows = $model->displayAccounts($access, $status);


											if (isset($_POST['search_department'])) {
												if ($_POST['search_dpt'] == "all") {
													$model = new Model();
													$rows = $model->displayAccounts($access, $status);
												}
												else {
													$model = new Model();
													$rows = $model->displayAccountsByDept(1, $_POST['search_dpt'], 2);
												}
											}

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$uid = $row['id'];
													$school_id = $row['school_id'];
													$fname = strtoupper($row['fname']);
													$mname = strtoupper($row['mname']);
													$lname = strtoupper($row['lname']);
													$email = strtolower($row['email']);
													$college = $row['college'];
													$section = $row['section'];
													$contact = $row['contact'];
													$date_added = date('M d, Y g:i A', strtotime($row['date_added']));
													
													if ($row['photo'] == "") {
														$photo = "default";
													}
													else {
														$photo = $row['photo'];
													}

													if ($row['verified'] == 0) {
													$ver = "<span style='color: red;'>NOT VERIFIED</span>";
													}
													else {
														$ver = "<span style='color: green;'>VERIFIED</span>";
													}

													if ($row['status'] == 3) {
													$ver = "<span style='color: orange;'><a data-toggle='modal' data-target='#unlock-".$uid."'>LOCKED</a></span>";
													}

												?>
											<tr>
												<td><?php echo $school_id; ?></td>
												<td><a href="../assets/images/profile-img/<?php echo $photo; ?>.jpg" target="_blank"><img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 30px; height: 30px; border-radius: 50%;object-fit: cover;">&nbsp;</a>&nbsp;<?php echo $fname." ".$mname." ".$lname; ?></td>
												<td><?php echo $email; ?></td>
												<td><?php echo $college; ?></td>
												<!-- <td style="font-size: 14px;"><center><b><?php echo $ver; ?></b></center></td> -->
												<td>
													<center>
														<a href="account-profile2?id=<?php echo $uid; ?>" class="btn blue" style="width: 50px; height: 37px;" data-toggle="tooltip" title="Profile"><i class="ti-search" style="font-size: 12px;"></i></a>&nbsp;
														<button data-toggle="modal" data-target="#archive-<?php echo $uid; ?>" class="btn red" style="width: 50px; height: 37px;">
															<div data-toggle="tooltip" title="Archive">
																<i class="ti-archive" style="font-size: 12px;"></i>
															</div>
														</button>
													</center>
												</td>
											</tr>
											<div id="archive-<?php echo $uid; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Archive Teacher Account</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																		<input type="hidden" name="user_id" value="<?php echo $uid; ?>">
																		<div class="col-lg-1"></div>
																		<div class="col-lg-10">
																			<center><img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																			<h4><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h4>
																			<h6><?php echo $college; ?></h6>
																			<h6><?php echo $contact; ?></h6>
																			<h6><?php echo $email; ?></h6>
																			</center>
																		</div>
																		<div class="col-lg-1"></div>
																</div>
															</div>
															<div class="modal-footer">
																<input type="submit" class="btn red radius-xl outline" name="archive" value="Archive">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
											<div id="unlock-<?php echo $uid; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Unlock Teacher Account</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																		<input type="hidden" name="user_idd" value="<?php echo $uid; ?>">
																		<div class="col-lg-1"></div>
																		<div class="col-lg-10">
																			<center><img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																			<h4><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h4>
																			<h6><?php echo $college; ?></h6>
																			<h6><?php echo $contact; ?></h6>
																			<h6><?php echo $email; ?></h6>
																			</center>
																		</div>
																		<div class="col-lg-1"></div>
																</div>
															</div>
															<div class="modal-footer">
																<input type="submit" class="btn orange radius-xl outline" name="unlock" value="Unlock">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
											<?php

												}
											}	

												if (isset($_POST['unlock'])) {
													$aid = $_POST['user_idd'];
													$status = 1;
													$model->updateAccountStatus($status, $aid);
													echo "<script>window.open('faculty','_self');</script>";
												}

												if (isset($_POST['archive'])) {
													$aid = $_POST['user_id'];
													$status = 2;
													$model->updateAccountStatus($status, $aid);
													echo "<script>window.open('faculty','_self');</script>";
												}

											?>
										</tbody>
									</table>
								</div><br>
								<div align="right">
									<!--<a href="import-faculty" class="btn blue radius-xl"><i class="ti-import"></i>&nbsp;&nbsp;IMPORT FACULTY</a>&nbsp;&nbsp;-->
									<a href="archived-faculty" class="btn red radius-xl"><i class="ti-archive"></i><span>&nbsp;ARCHIVED TEACHER ACCOUNTS</span></a><br>
								</div>

								<div id="add-faculty" class="modal fade" role="dialog">
									<form class="edit-profile m-b30" method="POST">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;New Teacher Account</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
												<div class="modal-body">
													<div class="row">
														<div class="form-group col-12">
															<label for="school_id" class="col-form-label">School ID</label>
															<input name="school_id" id="school_id" class="form-control" type="text" onkeypress="return isNumber(event)" maxlength="15" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="first_name" class="col-form-label">First Name</label>
															<input name="first_name" id="first_name" class="form-control" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="middle_name" class="col-form-label">Middle Name</label>
															<input class="form-control" id="middle_name" name="middle_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="last_name" class="col-form-label">Last Name</label>
															<input class="form-control" id="last_name" name="last_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>
														<div class="form-group col-lg-12">
															<label for="department" class="col-form-label">Department</label>
															<select class="form-control" name="department" id="department" required>
																<option value="" disabled selected>Select Department</option>
																<?php
																$rows = $model->fetchDepartments();
																if (!empty($rows)) {
																	foreach ($rows as $row) {
																		$dept_name = $row['dept_name'];
																		echo '<option value="'.$dept_name.'">'.$dept_name.'</option>';
																	}
																}
																?>
															</select>
														</div>
														<div class="form-group col-lg-6">
															<label for="occupation" class="col-form-label">Contact</label>
															<input class="form-control" id="contact" name="contact" type="number" required maxlength="15">
														</div>
														<div class="form-group col-lg-6">
															<label for="email" class="col-form-label">Email</label>
															<input class="form-control" name="email" id="email" type="email" required maxlength="50">
														</div>
														<div class="form-group col-lg-6">
															<label for="password" class="col-form-label">Password</label>
															<input class="form-control" name="password" type="password" id="password" minlength="5" maxlength="30" style="z-index: 0; position: relative;" required>
														</div>
														<div class="form-group col-lg-6">
															<label for="confirm_password" class="col-form-label">Confirm Password</label>
															<input class="form-control" name="confirm_password" type="password" id="confirm_password" minlength="5" maxlength="30" required>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="submit" class="btn green radius-xl outline" name="save">Save</button>
													<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</form>
								</div>
								<?php
									if (isset($_POST['save'])) {
										$school_id = $_POST['school_id'];
										$fname = ucwords(strtolower($_POST['first_name']));
										$mname = ucwords(strtolower($_POST['middle_name']));
										$lname = ucwords(strtolower($_POST['last_name']));
										$department = $_POST['department'];
										$year = "";
										$section = "";
										$email = strtolower($_POST['email']);
										$contact = $_POST['contact'];
										$date_added = date("Y-m-d H:i:s");
										$pword = password_hash($_POST['password'], PASSWORD_DEFAULT);

										$model->addAccount($school_id, $fname, $mname, $lname, $email, $department, $year, $section, $contact, $pword, 1, 0, $date_added, 1);
										echo "<script>alert('Teacher account has been added!');window.open('faculty', '_self');</script>";	
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>   
		<script src="../dashboard/assets/js/jquery.dataTables.min.js"></script>
		<script src="../dashboard/assets/js/dataTables.bootstrap4.min.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$('#table').DataTable();
			});

			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip();
			});

			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z.Ññ ]+$/ 
					return re.test(keyChar); 
				} 
			}

			function isNumber(evt) {
				evt = (evt) ? evt : window.event;
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode > 31 && (charCode < 48 || charCode > 57)) {
					return false;
				}
				return true;
			}

			var password = document.getElementById("password"), confirm_password = document.getElementById("confirm_password");
			function validatePassword() {
				if(password.value != confirm_password.value) {
					confirm_password.setCustomValidity("Passwords Don't Match");
				} 

				else {
					confirm_password.setCustomValidity('');
				}
			}
			password.onchange = validatePassword;
			confirm_password.onkeyup = validatePassword;
		</script>
		</script>
	</body>

</html>