<?php
	if (empty($_SESSION['sess'])) {
		echo "<script>window.open('../','_self');</script>";
	}		

	$department_id = $_SESSION['sess'];
	$model = new Model();
	$department = $model->displayDepartment($department_id);
	if (!empty($department)) {
		foreach ($department as $dep) {
			$afl = $dep['affiliation'];
			$nm = $dep['name'];
			$unm = $dep['uname'];

			if ($dep['photo'] == "") {
				$photo = "default";
			}
			else {
				$photo = $dep['photo'];
			}
		}
	}

	$current_rows = $model->fetchCurrentSem();
	if (!empty($current_rows)) { 
		foreach ($current_rows as $current_row) {
			$csid = $current_row['sem_id'];
			$csy = $current_row['syear'];
			$csm = $current_row['sem'];
		}
	}
?> 