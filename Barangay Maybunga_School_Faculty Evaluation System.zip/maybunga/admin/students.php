<?php
	session_start(); 
	include('../global/model.php');
	include('department.php');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">

		<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'students';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head">Students<span> Accounts</span></h2>
				</div>	
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<a href="" data-toggle="modal" data-target="#add-student" class="btn green radius-xl" style="float: right;"><i class="fa fa-users" style="font-size: 14px;"></i><span>&nbsp;&nbsp;ADD STUDENT ACCOUNT</span></a>
								<br><br>
								<form method="POST">
									<div class="row">
										<div class="col-lg-3">
										</div>
										<div class="col-lg-2">
											<select class="form-control" name="year1" id="year1" required>
												<option value="" disabled selected>Select Year</option>
												<option value="0">Kindergarten</option>
												<option value="1">Grade 1</option>
												<option value="2">Grade 2</option>
												<option value="3">Grade 3</option>
												<option value="4">Grade 4</option>
												<option value="5">Grade 5</option>
												<option value="6">Grade 6</option>
											</select>
										</div>
										<div class="col-lg-2">
											<select class="form-control" name="section1" id="section1" required>
												<option value="" disabled selected>Select Section</option>
											</select>
										</div>
										<div class="col-lg-2">
											<button type="submit" name="search_department" class="btn yellow radius-xl">
												<i class="ti-search"></i>
												<span>&nbsp;&nbsp;SEARCH</span>
											</button>
										</div>
										<div class="col-lg-3">
										</div>
									</div>
								</form>
								<?php
									if (isset($_POST['search_department'])) {
										echo "<script>window.open('section-students?year=".$_POST['year1']."&section=".$_POST['section1']."', '_self');</script>";		
									}

								?>
								<br><br>
								<div class="table-responsive">
									<table id="table" class="table hover" style="width:100%">
										<thead>
											<tr>
												<th>School ID</th>
												<th>Name</th>
												<th>Email</th>
												<th>Year & Section</th>
												<th>Contact</th>
												<th width="100">Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$access = 0;
											$status = 2;
											$rows = $model->displayAccounts($access, $status);

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$uid = $row['id'];
													$school_id = $row['school_id'];
													$fname = strtoupper($row['fname']);
													$mname = strtoupper($row['mname']);
													$lname = strtoupper($row['lname']);
													$email = strtolower($row['email']);
													$college = $row['college'];
													$year = $row['year'];
													$section = $row['section'];
													$contact = $row['contact'];
													$date_added = date('M d, Y g:i A', strtotime($row['date_added']));
													
													if ($row['photo'] == "") {
														$photo = "default";
													}
													else {
														$photo = $row['photo'];
													}

													if ($row['verified'] == 0) {
													$ver = "<span style='color: red;'>NOT VERIFIED</span>";
													}
													else {
														$ver = "<span style='color: green;'>VERIFIED</span>";
													}

													if ($row['status'] == 3) {
													$ver = "<span style='color: orange;'><a data-toggle='modal' data-target='#unlock-".$uid."'>LOCKED</a></span>";
													}

												?>
											<tr>
												<td><?php echo $school_id; ?></td>
												<td><a href="../assets/images/profile-img/<?php echo $photo; ?>.jpg" target="_blank"><img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 30px; height: 30px; border-radius: 50%;object-fit: cover;">&nbsp;</a>&nbsp;<?php echo $fname." ".$mname." ".$lname; ?></td>
												<td><?php echo $email; ?></td>
												<td><?php echo $college; ?> <?php echo $year; ?>-<?php echo $section; ?></td>
												<!-- <td style="font-size: 14px;"><center><b><?php echo $ver; ?></b></center></td> -->
												<td><?php echo $contact; ?></td>
												<td>
													<center>
														<a href="account-profile3?id=<?php echo $uid; ?>" class="btn blue" style="width: 50px; height: 37px;" data-toggle="tooltip" title="Profile"><i class="ti-search" style="font-size: 12px;"></i></a>&nbsp;
														<button data-toggle="modal" data-target="#archive-<?php echo $uid; ?>" class="btn red" style="width: 50px; height: 37px;">
															<div data-toggle="tooltip" title="Archive">
																<i class="ti-archive" style="font-size: 12px;"></i>
															</div>
														</button>
													</center>
												</td>
											</tr>
											<div id="archive-<?php echo $uid; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Archive Student Account</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																		<input type="hidden" name="user_id" value="<?php echo $uid; ?>">

																		<div class="col-lg-1"></div>
																		<div class="col-lg-10">
																			<center><img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																		<h4><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h4>
																			<h6><?php echo $college; ?> <?php echo $year; ?>-<?php echo $section; ?></h6>
																			<h6><?php echo $contact; ?></h6>
																			<h6><?php echo $email; ?></h6>
																		</center>
																		</div>
																</div>
															</div>
															<div class="modal-footer">
																<input type="submit" class="btn red radius-xl outline" name="archive" value="Archive">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
											<div id="unlock-<?php echo $uid; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Unlock Faculty Account</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																	<input type="hidden" name="user_idd" value="<?php echo $uid; ?>">
																	<div class="col-lg-1"></div>
																	<div class="col-lg-10">
																		<center><img src="../assets/images/profile-img/<?php echo $photox; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																		<h4><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h4>
																			<h6><?php echo $college; ?></h6>
																			<h6><?php echo $year; ?>-<?php echo $section; ?></h6>
																			<h6><?php echo $contact; ?></h6>
																			<h6><?php echo $email; ?></h6>
																		</center>
																	</div>
																	<div class="col-lg-1"></div>
																</div>
															</div>
															<div class="modal-footer">
																<input type="submit" class="btn orange radius-xl outline" name="unlock" value="Unlock">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
											<?php

												}
											}	

												if (isset($_POST['unlock'])) {
													$aid = $_POST['user_idd'];
													$status = 1;
													$model->updateAccountStatus($status, $aid);
													echo "<script>window.open('students','_self');</script>";
												}

												if (isset($_POST['archive'])) {
													$aid = $_POST['user_id'];
													$status = 2;
													$model->updateAccountStatus($status, $aid);
													echo "<script>window.open('students','_self');</script>";
												}

											?>
										</tbody>
									</table>
								</div><br>
								<div align="right">
									<!--<a href="import-students" class="btn blue radius-xl"><i class="ti-import"></i>&nbsp;&nbsp;IMPORT STUDENTS</a>&nbsp;&nbsp;-->
									<a href="archived-students" class="btn red radius-xl"><i class="ti-archive"></i><span>&nbsp;ARCHIVED STUDENTS ACCOUNTS</span></a><br>
								</div>

								<div id="add-student" class="modal fade" role="dialog">
									<form class="edit-profile m-b30" method="POST">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;New Student Account</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
												<div class="modal-body">
													<div class="row">
														<div class="form-group col-12">
															<label for="school_id" class="col-form-label">LRN</label>
															<input name="school_id" id="school_id" class="form-control" type="text" onkeypress="return isNumber(event)" maxlength="15" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="first_name" class="col-form-label">First Name</label>
															<input name="first_name" id="first_name" class="form-control" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="middle_name" class="col-form-label">Middle Name</label>
															<input class="form-control" id="middle_name" name="middle_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>
														<div class="form-group col-lg-4">
															<label for="last_name" class="col-form-label">Last Name</label>
															<input class="form-control" id="last_name" name="last_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
														</div>

														<div class="col-lg-6">
															<div class="form-group">
																<div class="input-group">
																	<label for="year" class="col-form-label">Year</label>
																	<select class="form-control" name="year" id="year" required>
																		<option value="" disabled selected>Select Year</option>
																		<option value="0">Kindergarten</option>
        																<option value="1">Grade 1</option>
        																<option value="2">Grade 2</option>
        																<option value="3">Grade 3</option>
        																<option value="4">Grade 4</option>
        																<option value="5">Grade 5</option>
        																<option value="6">Grade 6</option>
																	</select>
																</div>
															</div>
														</div>
														<div class="col-lg-6">
															<div class="form-group">
																<div class="input-group">
																	<label for="section" class="col-form-label">Section</label>
																	<select class="form-control" name="section" id="section" required>
																		<option value="" disabled selected>Select Section</option>
																	</select>
																</div>
															</div>
														</div>
														<div class="form-group col-lg-6">
															<label for="occupation" class="col-form-label">Contact</label>
															<input class="form-control" id="contact" name="contact" type="number" required maxlength="15">
														</div>
														<div class="form-group col-lg-6">
															<label for="email" class="col-form-label">Email</label>
															<input class="form-control" name="email" id="email" type="email" required maxlength="50">
														</div>
														<div class="form-group col-lg-6">
															<label for="password" class="col-form-label">Password</label>
															<input class="form-control" name="password" type="password" id="password" minlength="5" maxlength="30" style="z-index: 0; position: relative;" required>
														</div>
														<div class="form-group col-lg-6">
															<label for="confirm_password" class="col-form-label">Confirm Password</label>
															<input class="form-control" name="confirm_password" type="password" id="confirm_password" minlength="5" maxlength="30" required>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="submit" class="btn green radius-xl outline" name="save">Save</button>
													<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</form>
								</div>
								<?php
									if (isset($_POST['save'])) {
										$school_id = $_POST['school_id'];
										$fname = ucwords(strtolower($_POST['first_name']));
										$mname = ucwords(strtolower($_POST['middle_name']));
										$lname = ucwords(strtolower($_POST['last_name']));
										$department = '';
										$year = $_POST['year'];
										$section = $_POST['section'];
										$email = strtolower($_POST['email']);
										$contact = $_POST['contact'];
										$date_added = date("Y-m-d H:i:s");
										$pword = password_hash($_POST['password'], PASSWORD_DEFAULT);

										$model->addAccount($school_id, $fname, $mname, $lname, $email, $department, $year, $section, $contact, $pword, 1, 0, $date_added, 0);
										echo "<script>alert('Student account has been added!');window.open('students', '_self');</script>";	
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$('#table').DataTable();
			});
		</script>
		<script type="text/javascript">
			$(function () {
				$('#year1').change(function() {
					if ($('#year1').val() == null) {}

					else {
						var year_id = $('#year1').val();

						$.ajax({
							url:'../assets/fetch-sections.php',
							method:'POST',
							data: {
						// 		course_id : course_id,
								year_id : year_id
							},
							success:function(data) {
								var response = JSON.parse(data); 
								var html = '<option value="" disabled selected>Select Section</option>';

								if (response[0] != 'No result') {

									response.forEach( function(item) {
										html += '<option value="'+item[1]+'">'+year_id+'-'+item[1]+'</option>';
									});
								}

								else {}

								$('#section1').html(html);
								$('#section1').selectpicker('refresh');
							}
						});
					}
				});

			});
		</script>
		<script type="text/javascript">
			$(function () {
				$('#year').change(function() {
					if ($('#year').val() == null) {}

					else {
						var year_id = $('#year').val();

						$.ajax({
							url:'../assets/fetch-sections.php',
							method:'POST',
							data: {
						// 		course_id : course_id,
								year_id : year_id
							},
							success:function(data) {
								var response = JSON.parse(data); 
								var html = '<option value="" disabled selected>Select Section</option>';

								if (response[0] != 'No result') {

									response.forEach( function(item) {
										html += '<option value="'+item[1]+'">'+year_id+'-'+item[1]+'</option>';
									});
								}

								else {}

								$('#section').html(html);
								$('#section').selectpicker('refresh');
							}
						});
					}
				});


				$.validator.addMethod('password', function(value, element) {
					var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}$/;
					var exclude = /^[^<>]+$/;
					var result = true;

					if(regex.test(value) == false || exclude.test(value) == false) {
						result = false;
					}

					return this.optional(element) || result;
				}, "Password must contain at least 8 characters, at least 1 uppercase and lowercase letter, at least 1 number, and any special character except < and >.");

				$('#registration').validate({
					ignore: ":hidden:not(select)",
					rules: {
						confirm_password: {
							equalTo : '[name="password"]'
						}
					},
					messages: {
						confirm_password: {
							equalTo: "Please enter the same password again."
						}
					},
					unhighlight: function (input) {
						$(input).removeClass('error');
						$(input).parents('.form-group').css('margin-bottom', '25px');
					},
					errorPlacement: function(error, element) {
						$(element).parents('.form-group').css('margin-bottom', '0px').append(error);
						$(element).parents('.form-group').find('.input-group').find('div').find('button').attr('style', 'border-color: #cd0a0a!important');
					} 
				});
			});
		</script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>   
		<script src="../dashboard/assets/js/jquery.dataTables.min.js"></script>
		<script src="../dashboard/assets/js/dataTables.bootstrap4.min.js"></script>


<!-- 		<script type="text/javascript">
			$(document).ready(function() {
				$('#course, #year').change(function() {
					var course = $('#course').val();
					var course_abv = $('#course').find(':selected').data('id');
					var semester = $('#semester').val();
					var year = $('#year').val();

					$.ajax({
						url: 'lib/fetch-sections.php',
						method: 'POST',
						data: {
							course : course,
							course_abv : course_abv,
							year : year
						},
						success:function(data) {
							$('#section').html(data);
							$('#section').selectpicker('refresh');
						}
					});

					$.ajax({
						url: 'lib/fetch-subjects.php',
						method: 'POST',
						data: {
							course : course,
							semester : semester,
							year : year
						},
						success:function(data) {
							$('#subject').html(data);
							$('#subject').selectpicker('refresh');
						}
					});
				});

				$('#table').DataTable();
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
		 -->
		<script type="text/javascript">
			

			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
	</body>

</html>