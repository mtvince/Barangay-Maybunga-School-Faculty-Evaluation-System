	<style type="text/css">
		.ttr-notify-header::after {
			background: linear-gradient(45deg, #2861AB 0%, #2861AB 100%)!important;
		}
	</style>
	<header class="ttr-header" style=" background: linear-gradient(45deg, #2861AB 0%, #2861AB 100%)!important;">
		<div class="ttr-header-wrapper">
			<div class="ttr-toggle-sidebar ttr-material-button">
				<i class="ti-close ttr-open-icon"></i>
				<i class="ti-menu ttr-close-icon"></i>
			</div>
			<div class="ttr-logo-box">
				<div>
					<a href="index" class="ttr-logo">
						<img alt="" class="ttr-logo-mobile" src="../assets/images/logo-white.png" style="width: 250px; height: 36px;">
						<img alt="" class="ttr-logo-desktop" src="../assets/images/logo-white.png" style="width: 250px; height: 36px;">
					</a>
				</div>
			</div>
			<div class="ttr-header-menu">
			</div>
			<div class="ttr-header-right ttr-with-seperator">
				<ul class="ttr-header-navigation">
					<li>
						<a href="#" class="ttr-material-button ttr-submenu-toggle"><span class="ttr-user-avatar"><i class="fa fa-cog fa-spinn" style="font-size: 32px;"></i></span></a>
						<div class="ttr-header-submenu noti-menu">
							<div class="ttr-notify-header">
								<span class="ttr-notify-text-top"><b><?php echo strtoupper($nm); ?></b></span>
								<span class="ttr-notify-text">System Administrator</span>
							</div>
							<div class="noti-box-list">
								<ul>
									<a href="my-profile" style="text-decoration: none;color: black;"><li>
										<span class="notification-icon dashbg-green">
											<i class="fa fa-user" style="font-size: 18px;"></i>
										</span>
										<span style="font-size: 22px;" style="color: black!important;">
											My Profile
										</span>
									</li></a><hr>
									<!-- <a href="manage-evaluation-status" style="text-decoration: none;color: black;"><li>
										
										<span class="notification-icon dashbg-pink" style="background-color: #38BAF8;color: white;">
											<i class="fa fa-table" style="font-size: 18px;"></i>
										</span>
										<span style="font-size: 20px;" style="color: black!important;">
											Evaluation Preview
										</span>
									</li></a><hr> -->
									<a href="change-password" style="text-decoration: none;color: black;"><li>
										
										<span class="notification-icon dashbg-yellow">
											<i class="fa fa-lock" style="font-size: 18px;"></i>
										</span>
										<span style="font-size: 22px;" style="color: black!important;">
											Change Password
										</span>
									</li></a><hr>
									<a href="logout" style="text-decoration: none;color: black;"><li>
										<span class="notification-icon dashbg-red">
											<i class="fa fa-sign-out" style="font-size: 18px;"></i>
										</span>
										<span style="font-size: 22px;" style="color: black!important;">
											Logout
										</span>
									</li></a>
								</ul>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</header>