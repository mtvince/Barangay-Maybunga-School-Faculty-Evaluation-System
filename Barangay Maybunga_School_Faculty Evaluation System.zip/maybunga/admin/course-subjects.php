<?php
	session_start(); 
	include('../global/model.php');
	include('department.php');

	$id = isset($_GET['id']) ? $_GET['id'] : '';
	$abv = isset($_GET['abv']) ? $_GET['abv'] : '';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">

		<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'subjects';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head">Subjects<span></span></h2>
				</div>	
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<div style="padding: 5px;"></div>
								<div class="row">
									<div class="col-lg-6 m-b30">
									<div class="row">
											<div class="col-lg-6">
												<div class="heading-bx left">
													<h2 class="title-head">Courses<span></span></h2>
												</div>
											</div>
											<div class="col-lg-6">
												<button type="button" class="btn yellow radius-xl" style="float: right;background-color: #2861AB;" data-toggle="modal" data-target="#add_course">
													<i class="ti-plus"></i>
													<span>&nbsp;&nbsp;ADD COURSE</span>
												</button>
											</div>
										</div>

									<div id="add_course" class="modal fade" role="dialog">
										<form class="edit-profile m-b30" method="POST">
											<div class="modal-dialog modal-lg">
												<div class="modal-content">
													<div class="modal-header">
														<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Add Course</h4>
														<button type="button" class="close" data-dismiss="modal">&times;</button>
													</div>
													<div class="modal-body">
														<div class="row">
															<div class="form-group col-12">
																<label class="col-form-label">Course Name</label>
																<input class="form-control" type="text" name="course_name" required>
															</div>
															<div class="form-group col-12">
																<label class="col-form-label">Abbreviation</label>
																<input class="form-control" type="text" name="course_abv" required>
															</div>
														</div>
													</div>
													<div class="modal-footer">
														<input type="submit" class="btn green radius-xl outline" name="add-course" value="Add">
														<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
													</div>
												</div>
											</div>
										</form>
									</div>
									<?php
										if (isset($_POST['add-course'])) {
											$course_name = $_POST['course_name'];
											$course_abv = strtoupper($_POST['course_abv']);
											$model->insertCourse($course_name, $course_abv, 1);
											echo "<script>window.open('course-subjects.php?id=".$id."&abv=".$abv."','_self');</script>";
										}
									?>
									<br>
									<div class="table-responsive">
										<table id="table" class="table hover" style="width:100%">
											<thead>
												<tr>
													<th>Course Name</th>
													<th>Abbreviation</th>
													<th width="100">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$rows = $model->displayCourses(1);

												if (!empty($rows)) {
													foreach ($rows as $row) {
														$course_id = $row['course_id'];
													?>
												<tr>
													<td><?php echo $row['course_name']; ?></td>
													<td><?php echo $row['course_abv']; ?></td>
													<td>
														<center>
															<a href="course-subjects?id=<?php echo $course_id; ?>&abv=<?php echo $row['course_abv']; ?>" class="btn blue" style="width: 50px; height: 37px;" data-toggle="tooltip" title="View Subjects"><i class="ti-search" style="font-size: 12px;"></i></a>&nbsp;
															<button data-toggle="modal" data-target="#archive-<?php echo $course_id; ?>" class="btn red" style="width: 50px; height: 37px;">
																<div data-toggle="tooltip" title="Delete">
																	<i class="ti-archive" style="font-size: 12px;"></i>
																</div>
															</button>
														</center>
													</td>
												</tr>
												<div id="archive-<?php echo $course_id; ?>" class="modal fade" role="dialog">
													<form class="edit-profile m-b30" method="POST">
														<div class="modal-dialog modal-md">
															<div class="modal-content">
																<div class="modal-header">
																	<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Delete Course?</h4>
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																</div>
																<div class="modal-body">
																	<input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
																	<center><h5><?php echo $row['course_name']; ?></h5></center>
																	<center><h4>Are you sure you want to DELETE<br>this course?</h4></center>
																</div>
																<div class="modal-footer">
																	<input type="submit" class="btn red radius-xl outline" name="archive" value="Confirm">
																	<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
																</div>
															</div>
														</div>
													</form>
												</div>

												<?php

													}
												}	

													if (isset($_POST['archive'])) {
														$course_idd = $_POST['course_id'];
														$status = 2;
														$model->updateCourseStatus($status, $course_idd);
														echo "<script>window.open('course-subjects.php?id=".$id."&abv=".$abv."','_self');</script>";
													}

												?>
											</tbody>
										</table>
									</div>
								</div>
								<div class="col-lg-6 m-b30">
									<div style="padding: 5px;"></div>
									<div class="heading-bx left" style="margin-bottom: 30px;">
										<div class="row">
											<div class="col-lg-6">
												<h2 class="title-head"><?php echo $abv; ?><span> Subjects</span></h2>
											</div>
											<div class="col-lg-6">
												<?php

													if (isset($_GET['id'])) {

												?>
												<button type="button" class="btn yellow radius-xl" style="float: right;background-color: #2861AB;" data-toggle="modal" data-target="#add_subject">
													<i class="ti-plus"></i>
													<span>&nbsp;&nbsp;ADD SUBJECT</span>
												</button>
												<?php

													}

												?>
											</div>
										</div>
										<div id="add_subject" class="modal fade" role="dialog">
										<form class="edit-profile m-b30" method="POST">
											<div class="modal-dialog modal-lg">
												<div class="modal-content">
													<div class="modal-header">
														<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Add Subject</h4>
														<button type="button" class="close" data-dismiss="modal">&times;</button>
													</div>
													<div class="modal-body">
														<div class="row">
															<div class="form-group col-12">
																<label class="col-form-label">Subject Code</label>
																<input class="form-control" type="text" name="subject_code" required>
															</div>
															<div class="form-group col-12">
																<label class="col-form-label">Subject Title</label>
																<input class="form-control" type="text" name="subject_title" required>
															</div>
															<div class="form-group col-12">
																<label class="col-form-label">Year</label>
																<select class="form-control" name="year" required>
																	<option value="1">First Year</option>
																	<option value="2">Second Year</option>
																	<option value="3">Third Year</option>
																	<option value="4">Fourth Year</option>
																</select>
															</div>
															<div class="form-group col-12">
																<label class="col-form-label">Semester</label>
																<select class="form-control" name="semester" required>
																	<option value="First Semester">First Semester</option>
																	<option value="Second Semester">Second Semester</option>
																</select>
															</div>
														</div>
													</div>
													<div class="modal-footer">
														<input type="submit" class="btn green radius-xl outline" name="add-subject" value="Add">
														<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
													</div>
												</div>
											</div>
										</form>
									</div>
									<?php

										if (isset($_POST['add-subject'])) {
											$subject_code = $_POST['subject_code'];
											$subject_title = $_POST['subject_title'];
											$year = $_POST['year'];
											$semester = $_POST['semester'];

											$model->insertSubject($id, $subject_code, $subject_title, $year, $semester, 1);

											echo "<script>window.open('course-subjects.php?id=".$id."&abv=".$abv."','_self');</script>";
										}

									?>
										<br><br>
										<form method="POST">
											<div class="row">
												<div class="col-lg-1">
												</div>
												<div class="col-lg-4">
													<select class="form-control" name="search_year" required>
														<option value="all">All Subjects</option>
														<option value="1" <?php echo (isset($_POST['search_year']) && $_POST['search_year'] == '1') ? 'selected' : ''; ?>>First Year</option>
														<option value="2" <?php echo (isset($_POST['search_year']) && $_POST['search_year'] == '2') ? 'selected' : ''; ?>>Second Year</option>
														<option value="3" <?php echo (isset($_POST['search_year']) && $_POST['search_year'] == '3') ? 'selected' : ''; ?>>Third Year</option>
														<option value="4" <?php echo (isset($_POST['search_year']) && $_POST['search_year'] == '4') ? 'selected' : ''; ?>>Fourth Year</option>
														<option value="4" <?php echo (isset($_POST['search_year']) && $_POST['search_year'] == '5') ? 'selected' : ''; ?>>Fifth Year</option>
													</select>
												</div>
												<div class="col-lg-4">
													<select class="form-control" name="search_semester" required>
														<option value="all">All Semester</option>
														<option value="First Semester" <?php echo (isset($_POST['search_semester']) && $_POST['search_semester'] == 'First Semester') ? 'selected' : ''; ?>>First Semester</option>
														<option value="Second Semester" <?php echo (isset($_POST['search_semester']) && $_POST['search_semester'] == 'Second Semester') ? 'selected' : ''; ?>>Second Semester</option>
													</select>
												</div>
												<div class="col-lg-2">
													<button type="submit" name="search" class="btn yellow radius-xl">
														<i class="ti-search"></i>
														<span>&nbsp;&nbsp;SEARCH</span>
													</button>
												</div>
												<div class="col-lg-1">
												</div>
											</div>
										</form>
									</div>
									<div class="table-responsive">
										<table id="table2" class="table hover" style="width:100%">
											<thead>
												<tr>
													<th>Code</th>
													<th>Title</th>
													<th>Semester</th>
													<th width="50">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php

												$rows = $model->displaySubjects($id, 1);

												if (isset($_POST['search'])) {

													if ($_POST['search_semester'] == "all" && $_POST['search_year'] == "all") {
														$rows = $model->displaySubjects($id, 1);
													}
													else if ($_POST['search_semester'] == "all") {
														$rows = $model->displaySubjectsFiltered2($id, 1, $_POST['search_year'], $_POST['search_semester']);
													}
													else if ($_POST['search_year'] == "all") {
														$rows = $model->displaySubjectsFiltered3($id, 1, $_POST['search_semester']);
													}
													else {
														if ($_POST['search_year'] == "all") {
															$model = new Model();
															$rows = $model->displaySubjects($id, 1);
														}
														else {
															$model = new Model();
															$rows = $model->displaySubjectsFiltered($id, 1, $_POST['search_year'], $_POST['search_semester']);
														}
													}

												}

												if (!empty($rows)) {
													foreach ($rows as $row) {
														$subject_id = $row['subject_id'];

														if ($row['semester'] == "First Semester") {
															$semesterr = "First";
														}
														else if ($row['semester'] == "Second Semester") {
															$semesterr = "Second";
														}
														else {
															$semesterr = "Error";
														}
													?>
												<tr>
													<td><?php echo $row['subject_code']; ?></td>
													<td><?php echo $row['subject_title']; ?></td>
													<td><?php echo $semesterr; ?></td>
													<td>
														<center>
															<!-- <a href="student-section?id=<?php echo $subject_id; ?>" class="btn blue" style="width: 50px; height: 37px;" data-toggle="tooltip" title="View Students"><i class="ti-search" style="font-size: 12px;"></i></a>&nbsp; -->
															<button data-toggle="modal" data-target="#archived-<?php echo $subject_id; ?>" class="btn red" style="width: 50px; height: 37px;">
																<div data-toggle="tooltip" title="Delete">
																	<i class="ti-archive" style="font-size: 12px;"></i>
																</div>
															</button>
														</center>
													</td>
												</tr>
												<div id="archived-<?php echo $subject_id; ?>" class="modal fade" role="dialog">
													<form class="edit-profile m-b30" method="POST">
														<div class="modal-dialog modal-md">
															<div class="modal-content">
																<div class="modal-header">
																	<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Delete Section?</h4>
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																</div>
																<div class="modal-body">
																	<input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
																	<center><h5><?php echo $row['subject_title']; ?></h5></center>
																	<center><h4>Are you sure you want to DELETE<br>this section?</h4></center>
																</div>
																<div class="modal-footer">
																	<input type="submit" class="btn red radius-xl outline" name="archivee" value="Confirm">
																	<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
																</div>
															</div>
														</div>
													</form>
												</div>

												<?php

													}
												}	

													if (isset($_POST['archivee'])) {
														$subject_id = $_POST['subject_id'];
														$status = 2;
														$model->updateSubjectStatus($status, $subject_id);

														echo "<script>window.open('course-subjects.php?id=".$id."&abv=".$abv."','_self');</script>";
													}

												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>   
		<script src="../dashboard/assets/js/jquery.dataTables.min.js"></script>
		<script src="../dashboard/assets/js/dataTables.bootstrap4.min.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$('#table').DataTable();
			});

			$(document).ready(function() {
				$('#table2').DataTable();
			});

			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
	</body>

</html>