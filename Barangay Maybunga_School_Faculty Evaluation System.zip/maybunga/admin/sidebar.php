

				<div class="ttr-sidebar-logo" style="background-image: url('../assets/images/background.png');background-position: center;background-repeat: no-repeat;background-size: cover;height: 135px;border-color: #222831;">
					<div class="ttr-sidebar-toggle-button">
						<i class="ti-arrow-left"></i>
					</div>
					<div style="padding-left: 12px; padding-top: 12px;">
						<div class="image">
							<img src="../assets/images/profile-img/<?php echo $photo; ?>.jpg" alt="User" style="width: 50px; height: 50px; border-radius: 50%;object-fit: cover;cover;border: 2px solid #E2E2E2;">
						</div>
						<div style="height: 8px;">
						</div>
						<div class="info-container">
							<div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white; font-size: 15px;"><b><?php echo strtoupper($nm); ?></b></div>
							<div class="email" style="color: white; font-size: 12px;"><?php echo $unm; ?></div>
						</div>
					</div>
				</div>