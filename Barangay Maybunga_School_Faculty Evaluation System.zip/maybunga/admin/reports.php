<?php

	error_reporting(0);
	ini_set('display_errors', 0);

	session_start(); 
	include('../global/model.php');
	include('department.php');

	$ins_id = "";
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dataTables.bootstrap4.min.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">

		<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		@media print {
		   .header, .footer {
              display:none;
           }
          body * {
            padding: 0px!important;
            margin: 0px!important;
            visibility: hidden;
          }
          /*#ttr-sidebar, .ttr-sidebar, #alert-box, .alert-box, header * { */
          /*  display: none; */
          /*  width: 10px;*/
          /*}*/
          #section-to-print, #section-to-print * {
            visibility: visible;
          }
          #section-to-print {
            position: absolute;
            left: 0;
            top: 0;
          }
        }
		</style>
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'reports';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head">Reports<span></span></h2>
				</div>	
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<br>
								<form method="POST">
									<div class="row">
										<div class="col-lg-2"></div>
										<div class="col-lg-2">
											<select class="form-control" name="department" id="department" required>
												<option value="" disabled selected>Select Department</option>
												<?php
													$rows = $model->fetchDepartments();
													if (!empty($rows)) {
														foreach ($rows as $row) {
															$dept_name = $row['dept_name'];
												?>
															<option value="<?php echo $dept_name; ?>"><?php echo $dept_name; ?></option>
												<?php
														}
													}
												?>
											</select>
										</div>
										<div class="col-lg-2">
											<select class="form-control" name="instructor" id="instructor" required>
												<option value="" disabled selected>Select Instructor</option>
											</select>
										</div>
										<div class="col-lg-2">
											<select class="form-control" name="school_year" required>
												<?php
													$previous_rows = $model->fetchPrevSem(999);
													if (!empty($previous_rows)) { 
														foreach ($previous_rows as $previous_row) {
												?>
															<option value="<?php echo $previous_row['sem_id']; ?>"><?php echo $previous_row['syear']; ?></option>
												<?php
															}
														}
												?>
											</select>
										</div>
										<div class="col-lg-2">
											<button type="submit" name="search" class="btn yellow radius-xl"><i class="ti-search"></i><span>&nbsp;&nbsp;VIEW EVALUATION</span></button>
										</div>
										<div class="col-lg-2"></div>
										<div class="col-lg-12">
										<?php 
										    if (isset($_POST['department'])) {
										        $ins_iddd = $_POST['instructor'];
									            $sy_iddd =$_POST['school_year'];
									    ?>
									        <br>
									        <center><a href="reports-chart?ins_id=<?php echo $ins_iddd; ?>&sy_id=<?php echo $sy_iddd; ?>">View Chart Report</a></center> 
									    
									    <?php
										    }
										?>
										</div>
									</div>
								</form>
								<?php

									if (isset($_POST['search'])) {
										$ins_id = $_POST['instructor'];
										
										
										$question_mean = $model->viewEvaluation2($_POST['instructor'], $_POST['school_year']);
										$wan1 = $_POST['instructor'];
										$wan2 = $_POST['school_year'];
										$wan3 = $_POST['semester'];
										if (!empty($question_mean)) {
											foreach ($question_mean as $mean) {
												$q1 = $mean['AVG(q1)'];
												$q2 = $mean['AVG(q2)'];
												$q3 = $mean['AVG(q3)'];
												$q4 = $mean['AVG(q4)'];
												$q5 = $mean['AVG(q5)'];
												$t_q1 = $q1 + $q2 + $q3 + $q4 + $q5;
												$t_q1 = $t_q1 / 5;
												$t_q1 = number_format($t_q1, 2);

												$q6 = $mean['AVG(q6)'];
												$q7 = $mean['AVG(q7)'];
												$q8 = $mean['AVG(q8)'];
												$q9 = $mean['AVG(q9)'];
												$q10 = $mean['AVG(q10)'];
												$t_q2 = $q6 + $q7 + $q8 + $q9 + $q10;
												$t_q2 = $t_q2 / 5;
												$t_q2 = number_format($t_q2, 2);

												$q11 = $mean['AVG(q11)'];
												$q12 = $mean['AVG(q12)'];
												$q13 = $mean['AVG(q13)'];
												$q14 = $mean['AVG(q14)'];
												$q15 = $mean['AVG(q15)'];
												$t_q3 = $q11 + $q12 + $q13 + $q14 + $q15;
												$t_q3 = $t_q3 / 5;
												$t_q3 = number_format($t_q3, 2);

												$q16 = $mean['AVG(q16)'];
												$q17 = $mean['AVG(q17)'];
												$q18 = $mean['AVG(q18)'];
												$q19 = $mean['AVG(q19)'];
												$q20 = $mean['AVG(q20)'];
												$t_q4 = $q16 + $q17 + $q18 + $q19 + $q20;
												$t_q4 = $t_q4 / 5;
												$t_q4 = number_format($t_q4, 2);

												$t_q5 = $t_q1 + $t_q2 + $t_q3 + $t_q4;
												$t_q5 = $t_q5 / 4;
												$t_q5 = number_format($t_q5, 2);

												if($t_q5 >= 4.00 && $t_q5 <= 5.00) {
													$t_q5t = "VERY SATISFACTORY";
												}
												else if($t_q5 >= 3.00 && $t_q5 <= 3.99) {
													$t_q5t = "SATISFACTORY";
												}
												else if($t_q5 >= 2.00 && $t_q5 <= 2.99) {
													$t_q5t = "GOOD";
												}
												else if($t_q5 >= 1.00 && $t_q5 <= 1.99) {
													$t_q5t = "FAIR";
												}
												else if($t_q5 >= 0.01 && $t_q5 <= 0.99) {
													$t_q5t = "POOR";
												}
												else {
													$t_q5t = "N/A";
												}
											}
										}
										
										
										
										$question_mean = $model->viewEvaluation($_POST['instructor'], $_POST['school_year']);

										if (!empty($question_mean)) {
											foreach ($question_mean as $mean) {
												$q1 = $mean['AVG(q1)'];
												$q2 = $mean['AVG(q2)'];
												$q3 = $mean['AVG(q3)'];
												$q4 = $mean['AVG(q4)'];
												$q5 = $mean['AVG(q5)'];
												$q6 = $mean['AVG(q6)'];
												$q7 = $mean['AVG(q7)'];
												$q8 = $mean['AVG(q8)'];
												$q9 = $mean['AVG(q9)'];
												$q10 = $mean['AVG(q10)'];
												$q11 = $mean['AVG(q11)'];
												$q12 = $mean['AVG(q12)'];
												$q13 = $mean['AVG(q13)'];
												$q14 = $mean['AVG(q14)'];
												$q15 = $mean['AVG(q15)'];
												$q16 = $mean['AVG(q16)'];
												$q17 = $mean['AVG(q17)'];
												$q18 = $mean['AVG(q18)'];
												$q19 = $mean['AVG(q19)'];
												$q20 = $mean['AVG(q20)'];
											}
										}
										
										
										
										
									}

								?>
								<br>
								<div id="section-to-print">
								<center>
									<img src="../assets/images/icon.png" style="width: 120px; height: 120px; border-radius: 50%;"><br>

									<?php

										$model = new Model();
										$account = $model->displayAccountProfile($ins_id);

										if (!empty($account)) {
											foreach ($account as $row) {
												$school_id = $row['school_id'];
												$fname = strtoupper($row['fname']);
												$mname = strtoupper($row['mname']);
												$lname = strtoupper($row['lname']);
												$email = strtolower($row['email']);
												$college = $row['college'];
												$year = $row['year'];
												$section = $row['section'];
												$contact = $row['contact'];
												$access = $row['access'];
												$date_added = date('M d, Y g:i A', strtotime($row['date_added']));

												if ($row['photo'] == "") {
													$photo = "default";
												}
												else {
													$photo = $row['photo'];
												}

												$current_rows = $model->fetchSemID($_POST['school_year']);
													if (!empty($current_rows)) { 
														foreach ($current_rows as $current_row) {
															$s_syear = $current_row['syear'];
														}
													}
											}
									?>
											<span style="font-size: 24px;"><?php echo $fname; ?> <?php echo $mname; ?> <?php echo $lname; ?></span><br>
											<span style="font-size: 22px;"><?php echo $college; ?></span><br>
											<span style="font-size: 18px;"><?php echo $s_syear; ?></span><br>

									<?php
										}
										else {

										}

									?>
								</center><br>
								<div class="table-responsive">
									<table class="table hover" style="width:100%">
										<thead>
											<tr>
												<th>#</th>
												<th>COMMITMENT</th>
												<th width="30">SA</th>
												<th width="30">A</th>
												<th width="30">N</th>
												<th width="30">D</th>
												<th width="30">SD</th>
												<?php

													if (isset($_POST['department'])) {
														echo "<th width='30'>MEAN</th>";
													}

												?>
											</tr>
										</thead>
										<tbody>
											<?php
											$status = 1;
											$type = 1;
											$question_number = 1;
											$rows = $model->displayQuestionares($type, $status);

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$qid = $row['id'];
												?>
											<tr>
												<td><?php echo $row['number']; ?>.</td>
												<td><?php echo $row['commitment']; ?></td>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);

														$count_array = [];
														$check_array = [];

														if (!empty($count_ans)) {
															foreach ($count_ans as $count) {
																$count_key = $count[$qnum];
																$count_num = $count['count'];

																$count_array[] = [(int)$count_key, $count_num];
															}
														}

														foreach ($count_array as $ch) {
															$check_array[] = $ch[0];
														}

														if (!in_array(1, $check_array)) {
															$count_array[] = [1, "0"];
														}

														if (!in_array(2, $check_array)) {
															$count_array[] = [2, "0"];
														}

														if (!in_array(3, $check_array)) {
															$count_array[] = [3, "0"];
														}

														if (!in_array(4, $check_array)) {
															$count_array[] = [4, "0"];
														}

														if (!in_array(5, $check_array)) {
															$count_array[] = [5, "0"];
														}

														sort($count_array);
													}

												?>
												<td><?php if (isset($_POST['department'])) { echo $count_array[0][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[1][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[2][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[3][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[4][1]; } ?></td>
												<?php

													if (isset($_POST['department'])) {
														echo "<td>".number_format((float)$$qnum, 2, '.', '')."</td>";
													}

												?>
											</tr>

											<?php
													$question_number++;
												}
											}	

											?>
											
											<?php 
											
											$sa1_total = "-";
											$a1_total = "-";
											$n1_total = "-";
											$d1_total = "-";
											$sd1_total = "-";
											
											$rowsq1 = $model->count_type1($_POST['instructor'], $_POST['school_year']);
                            				if (!empty($rowsq1)) {
                            					foreach ($rowsq1 as $rowq1) {
                            					$sa1_total = $rowq1['q1sa'] + $rowq1['q2sa'] + $rowq1['q3sa'] + $rowq1['q4sa'] + $rowq1['q5sa'];
                            					
                            					$a1_total = $rowq1['q1a'] + $rowq1['q2a'] + $rowq1['q3a'] + $rowq1['q4a'] + $rowq1['q5a'];
                            					
                            					$n1_total = $rowq1['q1n'] + $rowq1['q2n'] + $rowq1['q3n'] + $rowq1['q4n'] + $rowq1['q5n'];
                            					
                            					$d1_total = $rowq1['q1d'] + $rowq1['q2d'] + $rowq1['q3d'] + $rowq1['q4d'] + $rowq1['q5d'];
                            					
                            					$sd1_total = $rowq1['q1sd'] + $rowq1['q2sd'] + $rowq1['q3sd'] + $rowq1['q4sd'] + $rowq1['q5sd'];
                            					}
                            					
                            					$qt1_total = $sa1_total + $a1_total + $n1_total + $d1_total + $sd1_total;
                            			  	}
											?>
											<tr>
											    <td></td>
											    <td align="right"><b>TOTAL:</b></td>
											    <td><b><?php echo $sa1_total; ?></b></td>
											    <td><b><?php echo $a1_total; ?></b></td>
											    <td><b><?php echo $n1_total; ?></b></td>
											    <td><b><?php echo $d1_total; ?></b></td>
											    <td><b><?php echo $sd1_total; ?></b></td>
											    <?php

													if (isset($_POST['department'])) {
														echo "<td><b>$t_q1</b></td>";
													}

												?>
											</tr>
										</tbody>
									</table>
								</div><br>
								<div class="table-responsive">
									<table class="table hover" style="width:100%">
										<thead>
											<tr>
												<th>#</th>
												<th>KNOWLEDGE OF THE SUBJECT MATTER</th>
												<th width="30">SA</th>
												<th width="30">A</th>
												<th width="30">N</th>
												<th width="30">D</th>
												<th width="30">SD</th>
												<?php

													if (isset($_POST['department'])) {
														echo "<th width='30'>MEAN</th>";
													}

												?>
											</tr>
										</thead>
										<tbody>
											<?php
											$status = 1;
											$type = 2;
											$rows = $model->displayQuestionares($type, $status);

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$qid = $row['id'];
												?>
											<tr>
												<td><?php echo $row['number']; ?>.</td>
												<td><?php echo $row['commitment']; ?></td>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);
													}

												?>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);

														$count_array = [];
														$check_array = [];

														if (!empty($count_ans)) {
															foreach ($count_ans as $count) {
																$count_key = $count[$qnum];
																$count_num = $count['count'];

																$count_array[] = [(int)$count_key, $count_num];
															}
														}

														foreach ($count_array as $ch) {
															$check_array[] = $ch[0];
														}

														if (!in_array(1, $check_array)) {
															$count_array[] = [1, "0"];
														}

														if (!in_array(2, $check_array)) {
															$count_array[] = [2, "0"];
														}

														if (!in_array(3, $check_array)) {
															$count_array[] = [3, "0"];
														}

														if (!in_array(4, $check_array)) {
															$count_array[] = [4, "0"];
														}

														if (!in_array(5, $check_array)) {
															$count_array[] = [5, "0"];
														}

														sort($count_array);
													}

												?>
												<td><?php if (isset($_POST['department'])) { echo $count_array[0][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[1][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[2][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[3][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[4][1]; } ?></td>
												<?php

													if (isset($_POST['department'])) {
														echo "<td>".number_format((float)$$qnum, 2, '.', '')."</td>";
													}

												?>
											</tr>

											<?php
													$question_number++;
												}
											}	
												
											?>
											<?php 
											
											$sa1_total = "-";
											$a1_total = "-";
											$n1_total = "-";
											$d1_total = "-";
											$sd1_total = "-";
											
											$rowsq1 = $model->count_type2($_POST['instructor'], $_POST['school_year']);
                            				if (!empty($rowsq1)) {
                            					foreach ($rowsq1 as $rowq1) {
                            					$sa1_total = $rowq1['q1sa'] + $rowq1['q2sa'] + $rowq1['q3sa'] + $rowq1['q4sa'] + $rowq1['q5sa'];
                            					
                            					$a1_total = $rowq1['q1a'] + $rowq1['q2a'] + $rowq1['q3a'] + $rowq1['q4a'] + $rowq1['q5a'];
                            					
                            					$n1_total = $rowq1['q1n'] + $rowq1['q2n'] + $rowq1['q3n'] + $rowq1['q4n'] + $rowq1['q5n'];
                            					
                            					$d1_total = $rowq1['q1d'] + $rowq1['q2d'] + $rowq1['q3d'] + $rowq1['q4d'] + $rowq1['q5d'];
                            					
                            					$sd1_total = $rowq1['q1sd'] + $rowq1['q2sd'] + $rowq1['q3sd'] + $rowq1['q4sd'] + $rowq1['q5sd'];
                            					}
                            					
                            					$qt1_total = $sa1_total + $a1_total + $n1_total + $d1_total + $sd1_total;
                            			  	}
											?>
											<tr>
											    <td></td>
											    <td align="right"><b>TOTAL:</b></td>
											    <td><b><?php echo $sa1_total; ?></b></td>
											    <td><b><?php echo $a1_total; ?></b></td>
											    <td><b><?php echo $n1_total; ?></b></td>
											    <td><b><?php echo $d1_total; ?></b></td>
											    <td><b><?php echo $sd1_total; ?></b></td>
											    <?php

													if (isset($_POST['department'])) {
														echo "<td><b>$t_q3</b></td>";
													}

												?>
											</tr>
										</tbody>
									</table>
								</div><br>
								<div class="table-responsive">
									<table class="table hover" style="width:100%">
										<thead>
											<tr>
												<th>#</th>
												<th>TEACHING FOR INDEPENDENT LEARNING</th>
												<th width="30">SA</th>
												<th width="30">A</th>
												<th width="30">N</th>
												<th width="30">D</th>
												<th width="30">SD</th>
												<?php

													if (isset($_POST['department'])) {
														echo "<th width='30'>MEAN</th>";
													}

												?>
											</tr>
										</thead>
										<tbody>
											<?php
											$status = 1;
											$type = 3;
											$rows = $model->displayQuestionares($type, $status);

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$qid = $row['id'];
												?>
											<tr>
												<td><?php echo $row['number']; ?>.</td>
												<td><?php echo $row['commitment']; ?></td>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);
													}

												?>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);

														$count_array = [];
														$check_array = [];

														if (!empty($count_ans)) {
															foreach ($count_ans as $count) {
																$count_key = $count[$qnum];
																$count_num = $count['count'];

																$count_array[] = [(int)$count_key, $count_num];
															}
														}

														foreach ($count_array as $ch) {
															$check_array[] = $ch[0];
														}

														if (!in_array(1, $check_array)) {
															$count_array[] = [1, "0"];
														}

														if (!in_array(2, $check_array)) {
															$count_array[] = [2, "0"];
														}

														if (!in_array(3, $check_array)) {
															$count_array[] = [3, "0"];
														}

														if (!in_array(4, $check_array)) {
															$count_array[] = [4, "0"];
														}

														if (!in_array(5, $check_array)) {
															$count_array[] = [5, "0"];
														}

														sort($count_array);
													}

												?>
												<td><?php if (isset($_POST['department'])) { echo $count_array[0][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[1][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[2][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[3][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[4][1]; } ?></td>
												<?php

													if (isset($_POST['department'])) {
														echo "<td>".number_format((float)$$qnum, 2, '.', '')."</td>";
													}

												?>
											</tr>

											<?php
													$question_number++;
												}
											}	
												
											?>
											<?php 
											
											$sa1_total = "-";
											$a1_total = "-";
											$n1_total = "-";
											$d1_total = "-";
											$sd1_total = "-";
											
											$rowsq1 = $model->count_type3($_POST['instructor'], $_POST['school_year']);
                            				if (!empty($rowsq1)) {
                            					foreach ($rowsq1 as $rowq1) {
                            					$sa1_total = $rowq1['q1sa'] + $rowq1['q2sa'] + $rowq1['q3sa'] + $rowq1['q4sa'] + $rowq1['q5sa'];
                            					
                            					$a1_total = $rowq1['q1a'] + $rowq1['q2a'] + $rowq1['q3a'] + $rowq1['q4a'] + $rowq1['q5a'];
                            					
                            					$n1_total = $rowq1['q1n'] + $rowq1['q2n'] + $rowq1['q3n'] + $rowq1['q4n'] + $rowq1['q5n'];
                            					
                            					$d1_total = $rowq1['q1d'] + $rowq1['q2d'] + $rowq1['q3d'] + $rowq1['q4d'] + $rowq1['q5d'];
                            					
                            					$sd1_total = $rowq1['q1sd'] + $rowq1['q2sd'] + $rowq1['q3sd'] + $rowq1['q4sd'] + $rowq1['q5sd'];
                            					}
                            					
                            					$qt1_total = $sa1_total + $a1_total + $n1_total + $d1_total + $sd1_total;
                            			  	}
											?>
											<tr>
											    <td></td>
											    <td align="right"><b>TOTAL:</b></td>
											    <td><b><?php echo $sa1_total; ?></b></td>
											    <td><b><?php echo $a1_total; ?></b></td>
											    <td><b><?php echo $n1_total; ?></b></td>
											    <td><b><?php echo $d1_total; ?></b></td>
											    <td><b><?php echo $sd1_total; ?></b></td>
											    <?php

													if (isset($_POST['department'])) {
														echo "<td><b>$t_q3</b></td>";
													}

												?>
											</tr>
										</tbody>
									</table>
								</div><br>
								<div class="table-responsive">
									<table class="table hover" style="width:100%">
										<thead>
											<tr>
												<th>#</th>
												<th>MANAGEMENT OF LEARNING</th>
												<th width="30">SA</th>
												<th width="30">A</th>
												<th width="30">N</th>
												<th width="30">D</th>
												<th width="30">SD</th>
												<?php

													if (isset($_POST['department'])) {
														echo "<th width='30'>MEAN</th>";
													}

												?>
											</tr>
										</thead>
										<tbody>
											<?php
											$status = 1;
											$type = 4;
											$rows = $model->displayQuestionares($type, $status);

											if (!empty($rows)) {
												foreach ($rows as $row) {
													$qid = $row['id'];
												?>
											<tr>
												<td><?php echo $row['number']; ?>.</td>
												<td><?php echo $row['commitment']; ?></td>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);
													}

												?>
												<?php

													if (isset($_POST['department'])) {
														$qnum = "q".$question_number;

														$count_ans = $model->countAnswers($qnum, $_POST['instructor'], $_POST['school_year']);

														$count_array = [];
														$check_array = [];

														if (!empty($count_ans)) {
															foreach ($count_ans as $count) {
																$count_key = $count[$qnum];
																$count_num = $count['count'];

																$count_array[] = [(int)$count_key, $count_num];
															}
														}

														foreach ($count_array as $ch) {
															$check_array[] = $ch[0];
														}

														if (!in_array(1, $check_array)) {
															$count_array[] = [1, "0"];
														}

														if (!in_array(2, $check_array)) {
															$count_array[] = [2, "0"];
														}

														if (!in_array(3, $check_array)) {
															$count_array[] = [3, "0"];
														}

														if (!in_array(4, $check_array)) {
															$count_array[] = [4, "0"];
														}

														if (!in_array(5, $check_array)) {
															$count_array[] = [5, "0"];
														}

														sort($count_array);
													}

												?>
												<td><?php if (isset($_POST['department'])) { echo $count_array[0][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[1][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[2][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[3][1]; } ?></td>
												<td><?php if (isset($_POST['department'])) { echo $count_array[4][1]; } ?></td>
												<?php

													if (isset($_POST['department'])) {
														echo "<td>".number_format((float)$$qnum, 2, '.', '')."</td>";
													}

												?>
											</tr>

											<?php
													$question_number++;
												}
											}	
											?>
											<?php 
											
											$sa1_total = "-";
											$a1_total = "-";
											$n1_total = "-";
											$d1_total = "-";
											$sd1_total = "-";
											
											$rowsq1 = $model->count_type4($_POST['instructor'], $_POST['school_year']);
                            				if (!empty($rowsq1)) {
                            					foreach ($rowsq1 as $rowq1) {
                            					$sa1_total = $rowq1['q1sa'] + $rowq1['q2sa'] + $rowq1['q3sa'] + $rowq1['q4sa'] + $rowq1['q5sa'];
                            					
                            					$a1_total = $rowq1['q1a'] + $rowq1['q2a'] + $rowq1['q3a'] + $rowq1['q4a'] + $rowq1['q5a'];
                            					
                            					$n1_total = $rowq1['q1n'] + $rowq1['q2n'] + $rowq1['q3n'] + $rowq1['q4n'] + $rowq1['q5n'];
                            					
                            					$d1_total = $rowq1['q1d'] + $rowq1['q2d'] + $rowq1['q3d'] + $rowq1['q4d'] + $rowq1['q5d'];
                            					
                            					$sd1_total = $rowq1['q1sd'] + $rowq1['q2sd'] + $rowq1['q3sd'] + $rowq1['q4sd'] + $rowq1['q5sd'];
                            					}
                            					
                            					$qt1_total = $sa1_total + $a1_total + $n1_total + $d1_total + $sd1_total;
                            			  	}
											?>
											<tr>
											    <td></td>
											    <td align="right"><b>TOTAL:</b></td>
											    <td><b><?php echo $sa1_total; ?></b></td>
											    <td><b><?php echo $a1_total; ?></b></td>
											    <td><b><?php echo $n1_total; ?></b></td>
											    <td><b><?php echo $d1_total; ?></b></td>
											    <td><b><?php echo $sd1_total; ?></b></td>
											    <?php

													if (isset($_POST['department'])) {
														echo "<td><b>$t_q4</b></td>";
													}

												?>
											</tr>
										</tbody>
									</table>
								</div><br></div>
								<button onclick="window.print()" class="btn green radius-xl" style="background-color: #2861AB;float: right;"><i class="fa fa-print"></i><span>&nbsp; PRINT EVALUATION REPORT</span></button>
									    <br><br><br>
								<!-- <div align="right">
									<a href="archived-students" class="btn red radius-xl"><i class="ti-archive"></i><span>&nbsp;ARCHIVED STUDENTS ACCOUNTS</span></a><br>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>   
		<script src="../dashboard/assets/js/jquery.dataTables.min.js"></script>
		<script src="../dashboard/assets/js/dataTables.bootstrap4.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$('#department').change( function() {
					var department = $(this).val();
					
					$.ajax({
						url: 'vendor/fetch-instructors.php',
						method: 'POST',
						data: {
							department : department
						},
						success:function(data) {
							$('#instructor option[value=""]').prop('selected', true);

							$('#instructor').html(data);

							$('#instructor').selectpicker('refresh');
						}
					});
				});

				$('#table').DataTable();
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
	</body>

</html>