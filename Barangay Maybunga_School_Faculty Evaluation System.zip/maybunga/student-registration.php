
<?php

	session_start();
	include('global/model.php');

	$model = new Model();

	if (isset($_POST['submit'])) {
		$school_id = $_POST['school_id'];
		$fname = ucwords(strtolower($_POST['first_name']));
		$mname = ucwords(strtolower($_POST['middle_name']));
		$lname = ucwords(strtolower($_POST['last_name']));
		$department = '';
		$year = $_POST['year'];
		$section = $_POST['section'];
		$email = strtolower($_POST['email']);
		$contact = $_POST['contact'];
		$date_added = date("Y-m-d H:i:s");
		$pword = password_hash($_POST['password'], PASSWORD_DEFAULT);

		$model->addAccount($school_id, $fname, $mname, $lname, $email, $department, $year, $section, $contact, $pword, 1, 0, $date_added, 0);

		echo "<script>window.open('success', '_self');</script>";	
	}


?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />
		<meta property="og:image" content="assets/images/cover.png" />
		<meta name="format-detection" content="telephone=no">
		
		<link rel="icon" href="assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="assets/css/typography.css">
		<link rel="stylesheet" type="text/css" href="assets/css/shortcodes/shortcodes.css">
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<link class="skin" rel="stylesheet" type="text/css" href="assets/css/color/color-1.css">
		<style type="text/css">
			.red-hover {
				background-color: #ebbc40!important;
				color: white!important;
			}
			.red-hover:hover {
				background-color: #2861AB!important;
				color: white!important;
			}

			.error {
				border-color: #cd0a0a !important;
				color: #cd0a0a;
				font-size: 10px;
			}

			.account-heads {
				position: sticky;
				left:0;
				top:0;
				z-index: 1;
				width: 500px;
				min-width: 500px;
				height: 100vh;
				background-position: center;
				text-align: center;
				align-items: center;
				display: flex;
				vertical-align: middle;
			}
			.account-heads a{
				display:block;
				width:100%;
			}
			.account-heads:after{
				opacity:0.9;
				content:"";
				position:absolute;
				left:0;
				top:0;
				z-index:-1;
				width:100%;
				height:100%;
				background: transparent;
			}

			@media only screen and (max-width: 1200px) {
				.account-heads{
					width: 350px;
					min-width: 350px;
				}

			}

			@media only screen and (max-width: 991px) {
				.account-heads {
					width: 100%;
					min-width: 100%;
					height: 200px;
				}
			}

			@media screen and (max-width: 1920px) {
				button[data-id="department"] {
					width: 400px!important;
				}
			}

			@media screen and (max-width: 1000px) {
				button[data-id="department"] {
					width: 360px!important;
				}
			}

			@media screen and (max-width: 1920px) {
				button[data-id="year"] {
					width: 400px!important;
				}
			}

			@media screen and (max-width: 1000px) {
				button[data-id="year"] {
					width: 360px!important;
				}
			}

			@media screen and (max-width: 1920px) {
				button[data-id="section"] {
					width: 400px!important;
				}
			}

			@media screen and (max-width: 1000px) {
				button[data-id="section"] {
					width: 360px!important;
				}
			}

			@media screen and (max-width: 1920px) {
				button[data-id="gender"] {
					width: 400px!important;
				}
			}

			@media screen and (max-width: 1000px) {
				button[data-id="gender"] {
					width: 360px!important;
				}
			}

			.btn-group.bootstrap-select.input-group-btn.form-control {
				padding-top: 0px!important;
				padding-bottom: 0px!important;
			}

			.btn.dropdown-toggle.btn-default {
				border-width: 0px 0px 1px 0px!important;
				border-color: #ccc!important;
				padding-left: 0px!important;
				color: #606060!important;
			}

			.btn.dropdown-toggle.btn-default:hover {
				color: #606060!important;
			}

			.btn.dropdown-toggle.btn-default:focus {
				color: #606060!important;
			}

			tbody tr:hover {
				background-color: #d4d4d4;
			}
		</style>
	</head>
	<body id="bg">
		<div class="page-wraper">
			<div id="loading-icon-bx"></div>
			<div class="account-form">
				<div class="account-heads" style="background-image:url(assets/images/bg2.png);"></div>
				<div class="account-form-inner">
					<div class="account-container">
						<div class="heading-bx left">
							<h2 class="title-head">Student <span>Registration</span></h2>
						</div>						
						<form class="contact-bx" id="registration" method="POST">
							<div class="row placeani">
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label for="school_id">School ID</label>
											<input name="school_id" id="school_id" class="form-control" type="text" onkeypress="return isNumber(event)" maxlength="20" required>
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<div class="input-group">
											<label for="first_name">First Name</label>
											<input name="first_name" id="first_name" class="form-control" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<div class="input-group">
											<label for="middle_name">Middle Name</label>
											<input class="form-control" id="middle_name" name="middle_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
										</div>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<div class="input-group">
											<label for="last_name">Last Name</label>
											<input class="form-control" id="last_name" name="last_name" type="text" pattern="[A-Za-z.Ññ ]+" onkeypress="return blockSpecialChar(event)" maxlength="30" required>
										</div>
									</div>
								</div>
							
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label for="department">Year</label>
											<select class="form-control" name="year" id="year" required>
												<option value="" disabled selected>Select Year</option>
																		<option value="0">Kindergarten</option>
        																<option value="1">Grade 1</option>
        																<option value="2">Grade 2</option>
        																<option value="3">Grade 3</option>
        																<option value="4">Grade 4</option>
        																<option value="5">Grade 5</option>
        																<option value="6">Grade 6</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label for="department">Section</label>
											<select class="form-control" name="section" id="section" required>
												<option value="" disabled selected>Select Section</option>
											</select>
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label for="occupation">Contact</label>
											<input class="form-control" id="contact" name="contact" type="number" required maxlength="15">
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label for="email">Email</label>
											<input class="form-control" name="email" id="email" type="email" required maxlength="50">
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<div class="input-group">
											<label for="password" style="z-index: -1; position: absolute;">Password</label>
											<input class="form-control" name="password" type="password" id="password" minlength="8" maxlength="30" style="z-index: 0; position: relative;" required>
											<i id="toggle-password" style="margin-left: -30px; cursor: pointer; z-index: 1; position: relative;">👁<span style="margin-left: -12px;" id="block-eye">/</span></i>
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<div class="input-group">
											<label for="confirm_password">Confirm Password</label>
											<input class="form-control" name="confirm_password" type="password" id="confirm_password" minlength="8" maxlength="30" required>
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-forget" style="margin-bottom: 25px;">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" name="affirm_rights" id="affirm_rights" required>
											<label class="custom-control-label" for="affirm_rights" style="font-size: 13px;text-align: justify;">I hereby affirm my right to be informed, object to processing, access and rectify, suspend, or withdraw my personal data, and be indemnified in case of damages pursuant to the provisions of the Republic Act No. 10173 of the Philippines, Data Privacy Act of 2012 and its corresponding Implementing Rules and Regulations.</label>
										</div>
									</div>
								</div>
								<div class="col-lg-12 m-b30">
									<input name="submit" type="submit" value="Register" class="red-hover btn btn-block">
									<br><br>
									<center><p>Already have an account? <a href="index" style="color: #2861AB;">Login Here</a></p>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<script src="assets/js/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
		<script type="text/javascript">
			$(function () {
				$('#year').change(function() {
					if ($('#year').val() == null) {}

					else {
						var year_id = $('#year').val();

						$.ajax({
							url:'assets/fetch-sections.php',
							method:'POST',
							data: {
						// 		course_id : course_id,
								year_id : year_id
							},
							success:function(data) {
								var response = JSON.parse(data); 
								var html = '<option value="" disabled selected>Select Section</option>';

								if (response[0] != 'No result') {

									response.forEach( function(item) {
										html += '<option value="'+item[1]+'">'+year_id+'-'+item[1]+'</option>';
									});
								}

								else {}

								$('#section').html(html);
								$('#section').selectpicker('refresh');
							}
						});
					}
				});

				$.validator.addMethod('password', function(value, element) {
					var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}$/;
					var exclude = /^[^<>]+$/;
					var result = true;

					if(regex.test(value) == false || exclude.test(value) == false) {
						result = false;
					}

					return this.optional(element) || result;
				}, "Password must contain at least 8 characters, at least 1 uppercase and lowercase letter, at least 1 number, and any special character except < and >.");

				$('#registration').validate({
					ignore: ":hidden:not(select)",
					rules: {
						confirm_password: {
							equalTo : '[name="password"]'
						}
					},
					messages: {
						confirm_password: {
							equalTo: "Please enter the same password again."
						}
					},
					unhighlight: function (input) {
						$(input).removeClass('error');
						$(input).parents('.form-group').css('margin-bottom', '25px');
					},
					errorPlacement: function(error, element) {
						$(element).parents('.form-group').css('margin-bottom', '0px').append(error);
						$(element).parents('.form-group').find('.input-group').find('div').find('button').attr('style', 'border-color: #cd0a0a!important');
					} 
				});
			});

			$('#gender').change(function() {
				$(this).parents('.input-group').find('div').find('button').removeAttr('style');
				$(this).parents('.input-group').parents('.form-group').find('label.error').remove();
				$(this).parents('.input-group').parents('.form-group').css('margin-bottom', '25px');
			});

			$('#civil_status').change(function() {
				$(this).parents('.input-group').find('div').find('button').removeAttr('style');
				$(this).parents('.input-group').parents('.form-group').find('label.error').remove();
				$(this).parents('.input-group').parents('.form-group').css('margin-bottom', '25px');
			});
		</script>
		<script src="assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendors/counter/waypoints-min.js"></script>
		<script src="assets/vendors/counter/counterup.min.js"></script>
		<script src="assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="assets/vendors/masonry/masonry.js"></script>
		<script src="assets/vendors/masonry/filter.js"></script>
		<script src="assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src="assets/js/functions.js"></script>
		<script src="assets/js/contact.js"></script>
		<script type="text/javascript">
			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z.Ññ ]+$/ 
					return re.test(keyChar); 
				} 
			}

			function isNumber(evt) {
				evt = (evt) ? evt : window.event;
				var charCode = (evt.which) ? evt.which : evt.keyCode;
				if (charCode > 31 && (charCode < 48 || charCode > 57)) {
					return false;
				}
				return true;
			}

			$('#toggle-password').click( function() {
				if ($('#block-eye').length) {
					$('#block-eye').remove();
					$('#password').prop('type', 'text');
				}

				else {
					$(this).append('<span style="margin-left: -12px;" id="block-eye">/</span>');
					$('#password').prop('type', 'password');
				}
			});
		</script>
	</body>
</html>