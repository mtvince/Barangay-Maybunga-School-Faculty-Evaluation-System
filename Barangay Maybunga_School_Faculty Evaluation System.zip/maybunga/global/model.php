<?php

	use PHPMailer\PHPMailer\PHPMailer;

	date_default_timezone_set('Asia/Manila');
	Class Model {
		private $server = "localhost";
		private $username = "root";
		private $password = "";
 		private $dbname = "maybunga";
// 		private $username = "u134789687_maybunga1";
// 		private $password = "Ne=Bnst27";
// 		private $dbname = "u134789687_maybungadb1";
		private $conn;

		public function __construct() {
			try {
				$this->conn = new mysqli($this->server, $this->username, $this->password, $this->dbname);	
			} catch (Exception $e) {
				echo "Connection failed" . $e->getMessage();
			}
		}

		//ADMIN - SIGN IN
		public function signIn($uname, $pword) {
			$query = "SELECT id, pword FROM admin WHERE uname = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $uname);
				$stmt->execute();
				$stmt->bind_result($id, $hashed_pass);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						if (password_verify($pword, $hashed_pass)) {
							$_SESSION['sess'] = $id;
							echo "<script>window.open('admin/index','_self');</script>";
							exit();
						}

						else {
							echo "<center><h5 style='color: red;'>Incorrect Password</h5></center>";
							if (empty($_SESSION['lattempt'])) {
								$_SESSION['lattempt'] = 1;
							}
							
							else {
								switch ($_SESSION['lattempt']) {
									case 1:
										$_SESSION['lattempt']++;
										break;
									case 2:
										$_SESSION['lattempt']++;
										break;
									case 3:
										$_SESSION['lattempt']++;
										break;
									default:
										unset($_SESSION['lattempt']);
										setcookie('rlimited', '5', time() + (60 * 30), "/");
										setcookie('expiration_date_admin', time() + (60 * 30), time() + (60 * 30), "/");
										echo "<script>window.open('admin.php','_self');</script>";
								}
							}
						}
					}
				}
				else {
					echo "<script>alert('Email not found in database!');</script>";
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//USER - SIGN IN
		public function signInAccount($uname, $pword) {
			$query = "SELECT id, pword, access FROM accounts WHERE email = ? LIMIT 1";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $uname);
				$stmt->execute();
				$stmt->bind_result($id, $hashed_pass, $access);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						if (password_verify($pword, $hashed_pass)) {
							if ($access == 0) {
								$_SESSION['student_sess'] = $id;
								echo "<script>window.open('student/index','_self');</script>";
								exit();
							}

							elseif ($access == 1) {
								$_SESSION['faculty_sess'] = $id;
								echo "<script>window.open('faculty/index','_self');</script>";
								exit();
							}
						}

						else {
							if (empty($_SESSION['llattempt'])) {
								$_SESSION['llattempt'] = 1;
							}
							
							else {
								switch ($_SESSION['llattempt']) {
									case 1:
										$_SESSION['llattempt']++;
										break;
									case 2:
										$_SESSION['llattempt']++;
										break;
									case 3:
										$_SESSION['llattempt']++;
										break;
									case 4:
										$_SESSION['llattempt']++;
										break;
									case 5:
										$_SESSION['llattempt']++;
										break;
									case 6:
										$_SESSION['llattempt']++;
										break;
									case 7:
										$_SESSION['llattempt']++;
										break;
									case 8:
										$_SESSION['llattempt']++;
										break;
									default:
										unset($_SESSION['llattempt']);

										$update_query = "UPDATE accounts SET status = 1 WHERE id = ?";

										if ($update_stmt = $this->conn->prepare($update_query)) {
											$update_stmt->bind_param('i', $id);
											$update_stmt->execute();
											$update_stmt->close();
										}
								}
							}

							return 'Incorrect Password';
						}
					}
				}
				else {
					echo "<center><h5 style='color: red;'>Email not found in the database</h5></center>";
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//USER REGISTRATION
		public function addAccount($school_id, $fname, $mname, $lname, $email, $department, $year, $section, $contact, $pword, $status, $verified, $date_added, $access) {
			$query = "INSERT INTO accounts (school_id, fname, mname, lname, email, college, year, section, contact, pword, status, verified, date_added, access) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('isssssssssiisi', $school_id, $fname, $mname, $lname, $email, $department, $year, $section, $contact, $pword, $status, $verified, $date_added, $access);
				$stmt->execute();
				if($stmt->errno == 1062) {
					$_SESSION['in-use'] = $email;
					echo "<script>window.open('in-use.php','_self');</script>";
				} 

				else {
				
				}
				$stmt->close();
			}
			//return $data;
		}

		//ADMIN - DISPLAYING NG ADMIN PROFILE
		public function displayDepartment($department_id) {
			$data = null;
			$query = "SELECT * FROM admin WHERE id = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("i", $department_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAYING NG ACTIVE PROFILES NG USERS
		public function displayAccounts($access, $status) {
			$data = null;
			$query = "SELECT * FROM accounts WHERE access = ? AND NOT status = ? ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $access, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAYING NG ACTIVE PROFILES NG USERS BY DEPARTMENT
		public function displayAccountsByDept($access, $college, $status) {
			$data = null;
			$query = "SELECT * FROM accounts WHERE access = ? AND college = ? AND NOT status = ? ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('isi', $access, $college, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAYING NG STUDENTS PER SECTION
		public function displayStudentsSection($year, $section) {
			$data = null;
			$query = "SELECT * FROM accounts WHERE access = 0 AND year = ? AND section = ? AND status = 1 ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ss', $year, $section);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}


		//ADMIN - DISPLAYING NG ARCHIVED PROFILES NG USERS
		public function displayArchivedAccounts($access, $status) {
			$data = null;
			$query = "SELECT * FROM accounts WHERE access = ? AND status = ? ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $access, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//USER - DISPLAYING NG ACCOUNT PROFILES NG NAKA LOGIN
		public function displayAccountProfile($account_id) {
			$data = null;

			$query = "SELECT * FROM accounts WHERE id = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("i", $account_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}


		//ADMIN - UPDATE ADMIN NAME
		public function updateAdminProfile($name, $affiliation, $id) {
			$query = "UPDATE admin SET name = ?, affiliation = ? WHERE id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ssi', $name, $affiliation, $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - ARCHIVE/RESTORE FUNCTION FOR USERS
		public function updateAccountStatus($status, $aid) {
			$query = "UPDATE accounts SET status = ? WHERE id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $aid);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}

		//ADMIN - ON OFF EVALUATION PREVIEW
		public function updateEvaluationPreview($id) {
			$query = "UPDATE on_off SET status = ? WHERE id = 1";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $id);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}

		//ADMIN - CHANGE PASSWORD
		public function changePassword($id, $pword, $newpword) {
			$query = "SELECT id, pword FROM admin WHERE id = ? LIMIT 1";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $id);
				$stmt->execute();
				$stmt->bind_result($id, $hashed_pass);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						if (password_verify($pword, $hashed_pass)) {
							$sql = "UPDATE admin SET pword = ? WHERE id = ?";
							if ($ya = $this->conn->prepare($sql)) {
								$ya->bind_param("si", $newpword, $id);
								$ya->execute();
								$ya->close();
								echo "<script>alert('Password has been changed!');window.open('index','_self');</script>";
								exit();
							}
						}
						else {
							echo "<script>alert('Incorrect Current Password');</script>";
							if (empty($_SESSION['rlattempt'])) {
								$_SESSION['rlattempt'] = 1;
							}
							
							else {
								switch ($_SESSION['rlattempt']) {
									case 1:
										$_SESSION['rlattempt']++;
										break;
									case 2:
										$_SESSION['rlattempt']++;
										break;
									case 3:
										$_SESSION['rlattempt']++;
										break;
									case 4:
										$_SESSION['rlattempt']++;
										break;
									default:
										unset($_SESSION['rlattempt']);
										setcookie('rrlimited', '5', time() + (30), "/");
										echo "<script>alert('Reached limit!')</script>";
								}
							}
						}
					}
				}

				else {
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//USER - CHANGE PASSWORD
		public function changeUserPassword($id, $pword, $newpword) {
			$query = "SELECT id, pword FROM accounts WHERE id = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $id);
				$stmt->execute();
				$stmt->bind_result($id, $hashed_pass);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						if (password_verify($pword, $hashed_pass)) {
							$sql = "UPDATE accounts SET pword = ? WHERE id = ?";
							if ($ya = $this->conn->prepare($sql)) {
								$ya->bind_param("si", $newpword, $id);
								$ya->execute();
								$ya->close();
								echo "<script>alert('Password has been changed!');window.open('my-profile','_self');</script>";
								exit();
							}
						}
						else {
							echo "<script>alert('Incorrect Current Password');</script>";
							if (empty($_SESSION['rlattempt'])) {
								$_SESSION['rlattempt'] = 1;
							}
							
							else {
								switch ($_SESSION['rlattempt']) {
									case 1:
										$_SESSION['rlattempt']++;
										break;
									case 2:
										$_SESSION['rlattempt']++;
										break;
									case 3:
										$_SESSION['rlattempt']++;
										break;
									case 4:
										$_SESSION['rlattempt']++;
										break;
									default:
										unset($_SESSION['rlattempt']);
										setcookie('rrlimited', '5', time() + (30), "/");
										echo "<script>alert('Reached limit!')</script>";
								}
							}
						}
					}
				}

				else {
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//FORGOT PASSWORD - CHANGE PW
		public function verifiedChangePassword($id, $password) {
			$query = "UPDATE accounts SET pword = ? WHERE id = ?";
			
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('si', $password, $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//FORGET PASSWORD - VERIFICATION NG EMAIL IF EXISTING OR HINDI
		public function fetchEmailID($email) {
			$query = "SELECT id FROM accounts WHERE email = ? LIMIT 1";
			
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $email);
				$stmt->execute();
				$stmt->bind_result($id);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						return $id;
					}
				}
				else {
					return false;
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//EMAIL VERIFICATION - PAG ACTIVATE NG ACCOUNT ONCE TAMA YUNG CODE NA ININPUT
		public function verifyAccount($id) {
			$query = "UPDATE accounts SET status = 1 WHERE id = ?";

			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//FACULTY/STUDENT - UPDATE ACCOUNT
		public function updateAccount($college, $year, $section, $contact, $id) {
			$query =  "UPDATE accounts SET college = ?, year = ?, section = ?, contact = ? WHERE id = ?";

			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ssssi', $college, $year, $section, $contact, $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//USER - EMAIL VERIFICATION
		public function verifyAccountPortal($id) {
			$query = "UPDATE accounts SET verified = 1 WHERE id = ?";

			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - UPDATE PHOTO
		public function editAdminPhoto($unique, $department_id) {
			$query = "UPDATE admin SET photo = ? WHERE id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('si', $unique, $department_id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//USER - UPDATE PHOTO
		public function editUserPhoto($unique, $account_id) {
			$query = "UPDATE accounts SET photo = ? WHERE id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('si', $unique, $account_id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//USER - UNLOCK ACCOUNT
		public function unlockUserAccount($email, $contact, $birth_date) {
			$data = null;

			$query = "SELECT * FROM accounts WHERE email = ? AND contact = ? AND birth_date = ? LIMIT 1";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('sss', $email, $contact, $birth_date);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAYING NG COURSES
		public function displayCourses($status) {
			$data = null;
			$query = "SELECT * FROM course WHERE status = ? ORDER BY course_name ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DELETE NG COURSE
		public function updateCourseStatus($status, $course_id) {
			$query = "UPDATE course SET status = ? WHERE course_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $course_id);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}

		//ADMIN - DISPLAYING NG SECTIONS
		public function displaySections($status) {
			$data = null;
			$query = "SELECT * FROM sections WHERE status = ? ORDER BY section_name ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DELETE NG SECTION
		public function updateSectionStatus($status, $section_id) {
			$query = "UPDATE sections SET status = ? WHERE section_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $section_id);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('Error');</script>";
			}
		}

		//ADMIN - DISPLAYING NG SUBJECTS
		public function displaySubjects($status) {
			$data = null;
			$query = "SELECT * FROM subjects WHERE status = ? ORDER BY subject_title ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DELETE NG SUBJECTS
		public function updateSubjectStatus($status, $subject_id) {
			$query = "UPDATE subjects SET status = ? WHERE subject_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $subject_id);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}

		//ADMIN - ADD NG SUBJECTS
		public function insertSubject($course_id, $subject_code, $subject_title, $year, $semester, $status) {
			$query = "INSERT INTO subjects (course_id, subject_code, subject_title, year, semester, status) VALUES (?, ?, ?, ?, ?, ?)";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('issssi', $course_id, $subject_code, $subject_title, $year, $semester, $status);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - ADD NG COURSE
		public function insertCourse($course_name, $course_abv, $status) {
			$query = "INSERT INTO course (course_name, course_abv, status) VALUES (?, ?, ?)";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ssi', $course_name, $course_abv, $status);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - ADD NG SECTION
		public function insertSection($course_id, $year, $section_name, $status) {
			$query = "INSERT INTO sections (course_id, year, section_name, status) VALUES (?, ?, ?, ?)";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('issi', $course_id, $year, $section_name, $status);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - COUNT STUDENT PER SECTION
		public function count_student_section($year, $secname){
			$data = null;
			$query = "SELECT SUM(IF(access = '0',1,0)) as cstudentsection FROM accounts WHERE year = '$year' AND section = '$secname' AND status = 1";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}

		//ADMIN WIDGETS - COUNT FACULTY, STUDENT, SUBJECTS, SECTION
		public function count_users(){
			$data = null;
			$query = "SELECT SUM(IF(access = '0',1,0)) as cstudent, SUM(IF(access = '1',1,0)) as cfaculty FROM accounts WHERE status = 1";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
		public function count_subjects(){
			$data = null;
			$query = "SELECT SUM(IF(status = '1',1,0)) as csubject FROM subjects";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
		public function count_sections(){
			$data = null;
			$query = "SELECT SUM(IF(status = '1',1,0)) as csection FROM sections";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}

		public function count_message_faculty($account_id, $csid, $csm){
			$data = null;
			$query = "SELECT COUNT(id) as count_message FROM messages WHERE instructor_id = '$account_id' AND semester_id = '$csid' AND semester = '$csm' AND status = 1";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}

		public function count_message_student($account_id, $csid){
			$data = null;
			$query = "SELECT COUNT(id) as count_message FROM messages WHERE student_id = '$account_id' AND semester_id = '$csid'";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}

		public function count_subject_faculty($account_id, $csid) {
			$data = null;
			$query = "SELECT COUNT(id) as count_subject FROM instructor_subject WHERE instructor_id = ? AND semester_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $account_id, $csid);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		public function count_subject_student($year, $status) {
			$data = null;
			$query = "SELECT COUNT(subject_id) as count_subject FROM subjects WHERE year = ? AND status = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $year, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}


		//ADMIN - VERIFY SEMESTER
		public function verifySemester($syear) {
			$query = "SELECT syear FROM semester WHERE syear = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $syear);
				$stmt->execute();
				$stmt->bind_result($ssyear);
				$stmt->store_result();
				if($stmt->num_rows > 0) {
					if($stmt->fetch()) {
						$data = array($ssyear);
						return $data;
					}
				}
				else {
					return false;
				}
				$stmt->close();
			}
			$this->conn->close();
		}

		//ADMIN - VERIFY SEMESTER 2
		public function verifySemester2($syear) {
			$data = null;
			$query = "SELECT syear FROM semester WHERE syear = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("s", $syear);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - ADD SEMESTER
		public function addSemester($sy, $sm) {
			$query = "INSERT INTO semester (syear, sem, date_added, status) VALUES (?, ?, ?, ?)";

			if($stmt = $this->conn->prepare($query)) {
				$date = date("Y-m-d H:i:s");
				$status = 1;
				$stmt->bind_param('sssi', $sy, $sm, $date, $status);
				$stmt->execute();
				if($stmt->errno == 1062) {
					echo "<script>alert('School Year already exist!');</script>";
				} 
				else {
				
				}
				$stmt->close();
			}
		}

		//ADMIN - DISPLAY PREV SEMESTER
		public function fetchPrevSem($id) {
			$data = null;

			$query = "SELECT * FROM semester WHERE NOT sem_id = ? ORDER BY sem_id DESC";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - UPDATE SEMESTER
		public function updateSemester($sy, $sm, $id) {
			$query = "UPDATE semester SET syear = ?, sem = ? WHERE sem_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ssi', $sy, $sm, $id);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - DISPLAY CURRENT SEMESTER
		public function fetchCurrentSem() {
			$data = null;

			$query = "SELECT * FROM semester ORDER BY sem_id DESC LIMIT 1";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - CHECK IF OPEN YUNG EVALUATION DATA
		public function checkOn_Off() {
			$data = null;

			$query = "SELECT * FROM on_off WHERE id = 1";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAY SEM BY ID
		public function fetchSemID($s_id) {
			$data = null;

			$query = "SELECT * FROM semester WHERE sem_id = '$s_id' LIMIT 1";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//FACULTY REGISTRATION - DISPLAY DEPARTMENTS
		public function fetchDepartments() {
			$data = null;

			$query = "SELECT * FROM departments WHERE status = 1";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		public function displayQuestionares($type, $status) {
			$data = null;
			$query = "SELECT * FROM questionares WHERE type = ? AND status = ? ORDER BY number ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $type, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				if($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {
						$data[] = $row;
					}
				}

				else {
					$data[] = 'No result';
				}

				$stmt->close();
			}
			return $data;
		}

		//ADMIN - ARCHIVE QUESTIONARES
		public function updateQuestionaresStatus($status, $aid) {
			$query = "UPDATE questionares SET status = ? WHERE id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $aid);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}	

		//ADMIN - UPDATE QUESTIONARES
		public function updateQuestionare($new_number, $new_commitment, $eid) {
			$query = "UPDATE questionares SET number = ?, commitment = ? WHERE id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('isi', $new_number, $new_commitment, $eid);
				$stmt->execute();
				$stmt->close();
			}
			else {
				echo "<script>alert('error');</script>";
			}
		}

		public function displaySubjectsFiltered($status, $year) {
			$data = null;
			$query = "SELECT * FROM subjects WHERE status = ? AND year = ? ORDER BY subject_title ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('is', $status, $year);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		public function displaySubjectsFiltered2($status, $year) {
			$data = null;
			$query = "SELECT * FROM subjects WHERE status = ? AND year = ? ORDER BY subject_title ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('is', $status, $year);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		public function displaySubjectsFiltered3($status, $semester) {
			$data = null;
			$query = "SELECT * FROM subjects WHERE status = ? AND semester = ? ORDER BY subject_title ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('is', $status, $semester);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		public function displaySubjectsFiltered4($subject_id) {
			$data = null;
			$query = "SELECT * FROM subjects WHERE subject_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('i', $subject_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - DISPLAY SECTIONS
		public function displaySectionsSelection($year, $status) {
			$data = null;
			$query = "SELECT * FROM sections WHERE year = ? AND status = ? ORDER BY section_name ASC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $year, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				if($result->num_rows > 0) {
					while ($row = $result->fetch_assoc()) {
						$data[] = $row;
					}
				}
				$stmt->close();
			}
			return $data;
		}

		//STUDENT - DISPLAY COURSE ID
		public function fetchCourseID($course) {
			$data = null;
			$query = "SELECT course_id FROM course WHERE course_abv = ? LIMIT 1";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('s', $course);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//STUDENT - DISPLAY SECTION ID
		public function fetchSectionID($year, $section_name) {
			$data = null;
			$query = "SELECT section_id FROM sections WHERE year = ? AND section_name = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('is', $year, $section_name);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//ADMIN - IMPORT FACULTY / STUDENT
		public function importAccount($school_id, $fname, $mname, $lname, $college, $year, $section, $email, $contact, $pword, $status, $verified, $photo, $access, $date_added) {
			$query = "INSERT INTO accounts (school_id, fname, mname, lname, college, year, section, email, contact, pword, status, verified, photo, access, date_added) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('sssssssssssisis', $school_id, $fname, $mname, $lname, $college, $year, $section, $email, $contact, $pword, $status, $verified, $photo, $access, $date_added);
				$stmt->execute();
				$stmt->close();
			}
		}

		//ADMIN - DISPLAY INSTRUCTOR BY DEPARTMENT
		public function fetchInstructors($access, $college) {
			$data = null;
			$query = "SELECT * FROM accounts WHERE access = ? AND college = ? ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('is', $access, $college);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			
			return $data;
		}

		//FACULTY - DISPLAY SUBJECTS
		public function displayInstructorSubjects($account_id, $csid) {
			$data = null;
			$query = "SELECT a.*, c.year, c.section_name, d.subject_code, d.subject_title FROM instructor_subject AS a INNER JOIN sections AS c ON a.section_id = c.section_id INNER JOIN subjects AS d ON a.subject_id = d.subject_id WHERE a.instructor_id = ? AND a.semester_id = ?";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $account_id, $csid);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//FACULTY - ADD SUBJECT
		public function addFacultySubject($account_id, $semester, $section, $subject, $csid) {
			$query = "INSERT INTO instructor_subject (instructor_id, course_id, section_id, subject_id, semester_id) VALUES (?, ?, ?, ?, ?)";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('iiiii', $account_id, $semester, $section, $subject, $csid);
				$stmt->execute();
				$stmt->close();
			}
		}

		//STUDENT - DISPLAYING NG INSTRUCTOR SA SUBJECT
		public function displaySubjectInstructor($subject_id, $section_id, $semester_id) {
			$data = null;

			$query = "SELECT a.*, b.*, a.id as aid FROM instructor_subject as a INNER JOIN accounts AS b ON a.instructor_id = b.id WHERE a.subject_id = ? AND a.section_id = ? AND a.semester_id = ?";
			if($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param("iii", $subject_id, $section_id, $semester_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//FACULTY - DISPLAYING MESSAGES
		public function displayMessages($instructor_id, $semester_id, $status) {
			$data = null;
			$query = "SELECT * FROM messages WHERE instructor_id = ? AND semester_id = ? AND status = ? AND NOT message = '' ORDER BY date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('iii', $instructor_id, $semester_id, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		// public function displayMessages($instructor_id, $semester_id, $semester, $status) {
		// 	$data = null;
		// 	$query = "SELECT a.*, a.id as mid, b.*, c.year as cyear, c.section_name as csname, d.course_abv FROM messages as a INNER JOIN instructor_subject AS b ON a.instructor_subject_id = b.id INNER JOIN sections AS c ON b.section_id = c.section_id INNER JOIN course AS d ON b.course_id = d.course_id WHERE a.instructor_id = ? AND a.semester_id = ? AND a.semester = ? AND a.status = ? AND NOT a.message = '' ORDER BY a.date_added DESC";
		// 	if ($stmt = $this->conn->prepare($query)) {
		// 		$stmt->bind_param('iisi', $instructor_id, $semester_id, $semester, $status);
		// 		$stmt->execute();
		// 		$result = $stmt->get_result();
		// 		$num_of_rows = $stmt->num_rows;
		// 		while ($row = $result->fetch_assoc()) {
		// 			$data[] = $row;
		// 		}
		// 		$stmt->close();
		// 	}
		// 	return $data;
		// }

		//STUDENT - DISPLAYING MESSAGES
		public function displayMessages2($student_id, $semester_id, $status) {
			$data = null;
			$query = "SELECT a.*, a.id as mid, b.*, c.year as cyear, c.section_name as csname, e.* FROM messages as a INNER JOIN instructor_subject AS b ON a.instructor_subject_id = b.id INNER JOIN sections AS c ON b.section_id = c.section_id INNER JOIN accounts AS e ON a.instructor_id = e.id WHERE a.student_id = ? AND a.semester_id = ? AND a.status = ? AND NOT a.message = '' ORDER BY a.date_added DESC";
			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('iii', $student_id, $semester_id, $status);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}
			return $data;
		}

		//FACULTY / STUDENT - ARCHIVE MESSAGES
		public function updateMessageStatus($status, $message_id) {
			$query = "UPDATE messages SET status = ? WHERE id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $status, $message_id);
				$stmt->execute();
				$stmt->close();
			}

			else {
				echo "<script>alert('error');</script>";
			}
		}

		//STUDENT - SEND EVALUATION
		public function insertAnswers($instructor_id, $account_id, $csid, $csm, $instructor_suject_id, $q1, $q2, $q3, $q4, $q5, $q6, $q7, $q8, $q9, $q10, $q11, $q12, $q13, $q14, $q15, $q16, $q17, $q18, $q19, $q20) {
			$query = "INSERT INTO answers (instructor_id, student_id, semester_id, semester, instructor_subject_id, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('iiisiiiiiiiiiiiiiiiiiiiii', $instructor_id, $account_id, $csid, $csm, $instructor_suject_id, $q1, $q2, $q3, $q4, $q5, $q6, $q7, $q8, $q9, $q10, $q11, $q12, $q13, $q14, $q15, $q16, $q17, $q18, $q19, $q20);
				$stmt->execute();
				$last_id = $this->conn->insert_id;
				$stmt->close();
			}

			return $last_id;
		}

		//STUDENT - SEND FEEDBACK1
		public function insertMessage($answer_id, $instructor_id, $student_id, $instructor_subject_id, $message, $semester_id, $semester) {
			$query = "INSERT INTO messages (answer_id, instructor_id, student_id, instructor_subject_id, message, semester_id, semester, date_added, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)";

			if ($stmt = $this->conn->prepare($query)) {
				$date_added = date("Y-m-d H:i:s");
				$stmt->bind_param('iiiisiss', $answer_id, $instructor_id, $student_id, $instructor_subject_id, $message, $semester_id, $semester, $date_added);
				$stmt->execute();
				$stmt->close();
			}
		}

		//STUDENT - SEND FEEDBACK2
		public function updateMessage($message, $message_id) {
			$query = "UPDATE messages SET message = ? WHERE answer_id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('si', $message, $message_id);
				$stmt->execute();
				$stmt->close();
			}

			else {
				echo "<script>alert('error');</script>";
			}
		}

		//STUDENT - CHECK IF THE INSTRUCTOR IS ALREADY EVALUATED
		public function evaluatedChecker($account_id, $instructor_id, $instructor_subject_id) {
			$data = null;

			$query = "SELECT * FROM `answers` WHERE student_id = ? AND instructor_id = ? AND instructor_subject_id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('iii', $account_id, $instructor_id, $instructor_subject_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}

			return $data;
		}

		public function viewEvaluation($instructor_id, $semester_id) {
			$data = null;

			$query = "SELECT AVG(q1), AVG(q2), AVG(q3), AVG(q4), AVG(q5), AVG(q6), AVG(q7), AVG(q8), AVG(q9), AVG(q10), AVG(q11), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q17), AVG(q18), AVG(q19), AVG(q20) FROM answers WHERE instructor_id = ? AND semester_id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $instructor_id, $semester_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}

			return $data;
		}

		public function viewEvaluation2($instructor_id, $semester_id) {
			$data = null;

			$query = "SELECT AVG(q1), AVG(q2), AVG(q3), AVG(q4), AVG(q5), AVG(q6), AVG(q7), AVG(q8), AVG(q9), AVG(q10), AVG(q11), AVG(q12), AVG(q13), AVG(q14), AVG(q15), AVG(q16), AVG(q17), AVG(q18), AVG(q19), AVG(q20) FROM answers WHERE instructor_id = ? AND semester_id = ?";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $instructor_id, $semester_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}

			return $data;
		}

		public function countAnswers($question, $instructor_id, $semester_id) {
			$data = null;

			$query = "SELECT ".$question.", COUNT(*) as count FROM answers WHERE instructor_id = ? AND semester_id = ? GROUP BY ".$question." ORDER BY count DESC";

			if ($stmt = $this->conn->prepare($query)) {
				$stmt->bind_param('ii', $instructor_id, $semester_id);
				$stmt->execute();
				$result = $stmt->get_result();
				$num_of_rows = $stmt->num_rows;
				while ($row = $result->fetch_assoc()) {
					$data[] = $row;
				}
				$stmt->close();
			}

			return $data;
		}
		
		public function count_type1($instructor_id, $school_year){
			$data = null;
			$query = "SELECT 
			SUM(IF(q1 = '1',1,0)) as q1sa,
			SUM(IF(q2 = '1',1,0)) as q2sa,
			SUM(IF(q3 = '1',1,0)) as q3sa,
			SUM(IF(q4 = '1',1,0)) as q4sa,
			SUM(IF(q5 = '1',1,0)) as q5sa,
			
			SUM(IF(q1 = '2',1,0)) as q1a,
			SUM(IF(q2 = '2',1,0)) as q2a,
			SUM(IF(q3 = '2',1,0)) as q3a,
			SUM(IF(q4 = '2',1,0)) as q4a,
			SUM(IF(q5 = '2',1,0)) as q5a,
			
			SUM(IF(q1 = '3',1,0)) as q1n,
			SUM(IF(q2 = '3',1,0)) as q2n,
			SUM(IF(q3 = '3',1,0)) as q3n,
			SUM(IF(q4 = '3',1,0)) as q4n,
			SUM(IF(q5 = '3',1,0)) as q5n,
			
			SUM(IF(q1 = '4',1,0)) as q1d,
			SUM(IF(q2 = '4',1,0)) as q2d,
			SUM(IF(q3 = '4',1,0)) as q3d,
			SUM(IF(q4 = '4',1,0)) as q4d,
			SUM(IF(q5 = '4',1,0)) as q5d,
			
			SUM(IF(q1 = '5',1,0)) as q1sd,
			SUM(IF(q2 = '5',1,0)) as q2sd,
			SUM(IF(q3 = '5',1,0)) as q3sd,
			SUM(IF(q4 = '5',1,0)) as q4sd,
			SUM(IF(q5 = '5',1,0)) as q5sd
			
			FROM answers WHERE instructor_id = '$instructor_id' AND semester_id = '$school_year'";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
		
		public function count_type2($instructor_id, $school_year){
			$data = null;
			$query = "SELECT 
			SUM(IF(q6 = '1',1,0)) as q1sa,
			SUM(IF(q7 = '1',1,0)) as q2sa,
			SUM(IF(q8 = '1',1,0)) as q3sa,
			SUM(IF(q9 = '1',1,0)) as q4sa,
			SUM(IF(q10 = '1',1,0)) as q5sa,
			
			SUM(IF(q6 = '2',1,0)) as q1a,
			SUM(IF(q7 = '2',1,0)) as q2a,
			SUM(IF(q8 = '2',1,0)) as q3a,
			SUM(IF(q9 = '2',1,0)) as q4a,
			SUM(IF(q10 = '2',1,0)) as q5a,
			
			SUM(IF(q6 = '3',1,0)) as q1n,
			SUM(IF(q7 = '3',1,0)) as q2n,
			SUM(IF(q8 = '3',1,0)) as q3n,
			SUM(IF(q9 = '3',1,0)) as q4n,
			SUM(IF(q10 = '3',1,0)) as q5n,
			
			SUM(IF(q6 = '4',1,0)) as q1d,
			SUM(IF(q7 = '4',1,0)) as q2d,
			SUM(IF(q8 = '4',1,0)) as q3d,
			SUM(IF(q9 = '4',1,0)) as q4d,
			SUM(IF(q10 = '4',1,0)) as q5d,
			
			SUM(IF(q6 = '5',1,0)) as q1sd,
			SUM(IF(q7 = '5',1,0)) as q2sd,
			SUM(IF(q8 = '5',1,0)) as q3sd,
			SUM(IF(q9 = '5',1,0)) as q4sd,
			SUM(IF(q10 = '5',1,0)) as q5sd
			
			FROM answers WHERE instructor_id = '$instructor_id' AND semester_id = '$school_year'";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
		
		public function count_type3($instructor_id, $school_year){
			$data = null;
			$query = "SELECT 
			SUM(IF(q11 = '1',1,0)) as q1sa,
			SUM(IF(q12 = '1',1,0)) as q2sa,
			SUM(IF(q13 = '1',1,0)) as q3sa,
			SUM(IF(q14 = '1',1,0)) as q4sa,
			SUM(IF(q15 = '1',1,0)) as q5sa,
			
			SUM(IF(q11 = '2',1,0)) as q1a,
			SUM(IF(q12 = '2',1,0)) as q2a,
			SUM(IF(q13 = '2',1,0)) as q3a,
			SUM(IF(q14 = '2',1,0)) as q4a,
			SUM(IF(q15 = '2',1,0)) as q5a,
			
			SUM(IF(q11 = '3',1,0)) as q1n,
			SUM(IF(q12 = '3',1,0)) as q2n,
			SUM(IF(q13 = '3',1,0)) as q3n,
			SUM(IF(q14 = '3',1,0)) as q4n,
			SUM(IF(q15 = '3',1,0)) as q5n,
			
			SUM(IF(q11 = '4',1,0)) as q1d,
			SUM(IF(q12 = '4',1,0)) as q2d,
			SUM(IF(q13 = '4',1,0)) as q3d,
			SUM(IF(q14 = '4',1,0)) as q4d,
			SUM(IF(q15 = '4',1,0)) as q5d,
			
			SUM(IF(q11 = '5',1,0)) as q1sd,
			SUM(IF(q12 = '5',1,0)) as q2sd,
			SUM(IF(q13 = '5',1,0)) as q3sd,
			SUM(IF(q14 = '5',1,0)) as q4sd,
			SUM(IF(q15 = '5',1,0)) as q5sd
			
			FROM answers WHERE instructor_id = '$instructor_id' AND semester_id = '$school_year'";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
		
		public function count_type4($instructor_id, $school_year){
			$data = null;
			$query = "SELECT 
			SUM(IF(q16 = '1',1,0)) as q1sa,
			SUM(IF(q17 = '1',1,0)) as q2sa,
			SUM(IF(q18 = '1',1,0)) as q3sa,
			SUM(IF(q19 = '1',1,0)) as q4sa,
			SUM(IF(q20 = '1',1,0)) as q5sa,
			
			SUM(IF(q16 = '2',1,0)) as q1a,
			SUM(IF(q17 = '2',1,0)) as q2a,
			SUM(IF(q18 = '2',1,0)) as q3a,
			SUM(IF(q19 = '2',1,0)) as q4a,
			SUM(IF(q20 = '2',1,0)) as q5a,
			
			SUM(IF(q16 = '3',1,0)) as q1n,
			SUM(IF(q17 = '3',1,0)) as q2n,
			SUM(IF(q18 = '3',1,0)) as q3n,
			SUM(IF(q19 = '3',1,0)) as q4n,
			SUM(IF(q20 = '3',1,0)) as q5n,
			
			SUM(IF(q16 = '4',1,0)) as q1d,
			SUM(IF(q17 = '4',1,0)) as q2d,
			SUM(IF(q18 = '4',1,0)) as q3d,
			SUM(IF(q19 = '4',1,0)) as q4d,
			SUM(IF(q20 = '4',1,0)) as q5d,
			
			SUM(IF(q16 = '5',1,0)) as q1sd,
			SUM(IF(q17 = '5',1,0)) as q2sd,
			SUM(IF(q18 = '5',1,0)) as q3sd,
			SUM(IF(q19 = '5',1,0)) as q4sd,
			SUM(IF(q20 = '5',1,0)) as q5sd
			
			FROM answers WHERE instructor_id = '$instructor_id' AND semester_id = '$school_year'";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}
	}
?>