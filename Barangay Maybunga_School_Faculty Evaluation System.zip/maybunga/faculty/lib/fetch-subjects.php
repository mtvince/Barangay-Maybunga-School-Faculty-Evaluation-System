<?php

	session_start();
	include('../../global/model.php');
	$model = new Model();

	$output = '';

	$rows = $model->displaySubjectsFiltered($_POST['course'], 1, $_POST['year'], $_POST['semester']);

	if (!empty($rows)) {
		foreach ($rows as $row) {
			$output .= '<option value="'.$row['subject_id'].'">'.$row['subject_title'].'</option>';
		}
	}

	echo $output;

?>