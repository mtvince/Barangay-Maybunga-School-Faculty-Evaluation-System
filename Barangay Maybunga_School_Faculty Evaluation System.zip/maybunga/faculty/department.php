<?php
	if (empty($_SESSION['faculty_sess'])) {
		echo "<script>window.open('../','_self');</script>";
	}
	$account_id = $_SESSION['faculty_sess'];

	$model = new Model();
	$account = $model->displayAccountProfile($account_id);

	if (!empty($account)) {
		foreach ($account as $row) {
			$school_id = $row['school_id'];
			$fname = strtoupper($row['fname']);
			$mname = strtoupper($row['mname']);
			$lname = strtoupper($row['lname']);
			$email = strtolower($row['email']);
			$college = $row['college'];
			$year = $row['year'];
			$section = $row['section'];
			$contact = $row['contact'];
			$access = $row['access'];
			$date_added = date('M d, Y g:i A', strtotime($row['date_added']));

			if ($row['photo'] == "") {
				$photo = "default";
			}
			else {
				$photo = $row['photo'];
			}

			if ($row['verified'] == 0) {
				$ver = "<span style='color: red;'>NOT VERIFIED</span>";
			}
			else {
				$ver = "<span style='color: green;'>VERIFIED</span>";
			}
		}
	}

	$show1 = "";
	$show0 = "";
	if ($access == 1) {
		$show1 = "show";
		$label = "Faculty";
	}
	elseif ($access == 0) {
		$show0 = "show";
		$label = "Student";
	}
	else { 
		echo "<script>window.open('index','_self');</script>";
	}


	$current_rows = $model->fetchCurrentSem();
	if (!empty($current_rows)) { 
		foreach ($current_rows as $current_row) {
			$csid = $current_row['sem_id'];
			$csy = $current_row['syear'];
			$csm = $current_row['sem'];
		}
	}

	$current_rows = $model->checkOn_Off();
	if (!empty($current_rows)) { 
		foreach ($current_rows as $current_row) {
			$status_of = $current_row['status'];
		}
	}	
?> 