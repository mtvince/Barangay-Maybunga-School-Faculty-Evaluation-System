<?php

	session_start();
	include('global/model.php');

	// if (isset($_SESSION['student_sess'])) {
	// 	echo "<script>window.open('user/index','_self');</script>";
	// }

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta property="og:image" content="assets/images/cover.png" />
		<meta name="format-detection" content="telephone=no">
		
		<link rel="icon" href="assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="assets/css/typography.css">
		<link rel="stylesheet" type="text/css" href="assets/css/shortcodes/shortcodes.css">
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<link class="skin" rel="stylesheet" type="text/css" href="assets/css/color/color-1.css">
		<style type="text/css">
			.red-hover {
				background-color: #ebbc40!important;
				color: white!important;
			}
			.red-hover:hover {
				background-color: #2861AB!important;
				color: white!important;
			}
			.account-heads {
				position: sticky;
				left:0;
				top:0;
				z-index: 1;
				width: 500px;
				min-width: 500px;
				height: 100vh;
				background-position: center;
				text-align: center;
				align-items: center;
				display: flex;
				vertical-align: middle;
			}
			.account-heads a{
				display:block;
				width:100%;
			}
			.account-heads:after{
				opacity:0.9;
				content:"";
				position:absolute;
				left:0;
				top:0;
				z-index:-1;
				width:100%;
				height:100%;
				background: transparent;
			}

			@media only screen and (max-width: 1200px) {
				.account-heads{
					width: 350px;
					min-width: 350px;
				}

			}

			@media only screen and (max-width: 991px) {
				.account-heads {
					width: 100%;
					min-width: 100%;
					height: 200px;
				}
			}
		</style>
	</head>
	<body id="bg">
		<div class="page-wraper">
			<div id="loading-icon-bx"></div>
			<div class="account-form">
				<div class="account-heads" style="background-image:url(assets/images/bg2.png);"  style="background-color: transparent!important;"></div>
				<div class="account-form-inner">
					<div class="account-container">
						<div class="heading-bx left">
							<h2 class="title-head">Login <span>Account</span></h2>
						</div>
						<form class="contact-bx" method="POST">
							<div class="row placeani">
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group">
											<label>Your Email</label>
											<input name="email" type="email" class="form-control" required value="<?php (isset($_POST['email']))?$_POST['email']:''; ?>">
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<div class="input-group"> 
											<label>Your Password</label>
											<input name="password" type="password" class="form-control" minlength="5" maxlength="20" required>
										</div>
									</div>
								</div>
								<!-- <div class="col-lg-6">
									<div class="form-group form-forget">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
											<label class="custom-control-label" for="customControlAutosizing" style="color: #2861AB;">Remember me</label>
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<a href="forgot-password" class="ml-auto" style="color: #2861AB;">Forgot your password?</a>
								</div><br><br> -->
								<div class="col-lg-12 m-b30">
									<div id="submit-button">
										<?php

											if (isset($_COOKIE['rrlimited'])) {
												echo '<button name="submit" type="submit" value="Submit" class="red-hover btn btn-block" disabled>Login</button><br><br>';
											}

											else {
												echo '<button name="submit" type="submit" value="Submit" class="red-hover btn btn-block">Login</button>';
											}
										?>
									</div>
									<center>
									<?php if (isset($_COOKIE['expiration_date_student'])) { echo '<span style="color: red; font-size: 20px;">YOUR ACCOUNT IS DISABLED</span><br>'; } ?>
									<p id="timer" style="color: red; font-size: 20px;">
										<?php

											function formatSeconds($seconds) {
  												$t = round($seconds);
  												return sprintf('%02d:%02d', ($t/60%60), $t%60);
											}

											if (isset($_COOKIE['expiration_date_student'])) { 
												$time_left = $_COOKIE['expiration_date_student'] - time();
												echo formatSeconds($time_left);
											} 
										?>
									</p></center>
									<?php  

										if (isset($_POST['submit'])) {
											if (!isset($_COOKIE['rrlimited'])) {
												$uname = $_POST['email'];
												$pword = $_POST['password'];

												$model = new Model();
												$incorrect = $model->signInAccount($uname, $pword);

												if (!empty($incorrect)) {
													echo "<center><h5 style='color: red;'>Incorrect Password</h5></center>";
												}
											}

											else {
												echo "<script>alert('Too many attempts. Please try again later.')</script>";
											}
										}

									?><br>
									<center><p>Don't have an account?</p>
									<div class="row">
										<div class="col-lg-6"><a href="faculty-registration" style="color: #2861AB;"><b>Faculty Registration</b></a></div>
										<div class="col-lg-6"><a href="student-registration" style="color: #2861AB;"><b>Student Registration</b></a></div>
									</div><br>
									<h6>OR</h6><div style="padding: 4px;"></div>
									<a href="admin.php" style="color: #2861AB;"><b>Login as Administrator</b></a></p>
									</center>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<script src="assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				var timer = setInterval(function() {
					var timer_text = $('#timer').text();
					const timer_split = timer_text.split(':');
					var seconds = (timer_split[0] * 60) + timer_split[1];

					if (parseInt(seconds) > 0) {
						$('#timer').load(location.href + " #timer");
					}

					else {
						$('#timer').html('');
					}

					$('#submit-button').load(location.href + " #submit-button");
				}, 1000);
			});
		</script>
		<script src="assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendors/counter/waypoints-min.js"></script>
		<script src="assets/vendors/counter/counterup.min.js"></script>
		<script src="assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="assets/vendors/masonry/masonry.js"></script>
		<script src="assets/vendors/masonry/filter.js"></script>
		<script src="assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src="assets/js/functions.js"></script>
		<script src="assets/js/contact.js"></script>
	</body>
</html>
