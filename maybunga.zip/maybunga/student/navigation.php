				<style type="text/css">
					.ttr-sidebar-navi ul li.show > a {
						background-color: #D6AE43!important;
					}

					.ttr-material-button:hover {
						background-color: #D6AE43!important;
					}

					.ttr-label, .ttr-icon > i {
						color: white;
					}
				</style>
				<nav class="ttr-sidebar-navi">
					<ul>
						<li style="padding-left: 20px; padding-top: 5px; padding-bottom: 5px; margin-top: 0px; margin-bottom: 0px;">
							<span class="ttr-label" style="color: #D5D6D8; font-weight: 500;">Menu</span>
						</li>
						<li class="<?php echo ($page == 'dashboard') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="index" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-home" aria-hidden="true"></i></span>
								<span class="ttr-label">Dashboard</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'subjects') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="subjects" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-book" aria-hidden="true"></i></span>
								<span class="ttr-label">Subjects</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'evaluation-form') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="evaluation-form" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-list-alt" aria-hidden="true"></i></span>
								<span class="ttr-label">Evaluation Form</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'messages') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="messages" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
								<span class="ttr-label">Messages</span>
							</a>
						</li>
					</ul>
				</nav>
				
				
				