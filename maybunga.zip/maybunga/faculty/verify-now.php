<?php

	session_start();
	include('../global/model.php');
	include('department.php');

	use PHPMailer\PHPMailer\PHPMailer;

	$verification_key = random_int(100000, 999999);
	$hashed_key = password_hash($verification_key, PASSWORD_DEFAULT);

	require_once "PHPMailer/PHPMailer.php";
	require_once "PHPMailer/SMTP.php";
	require_once "PHPMailer/Exception.php";

	$mail = new PHPMailer();

	$mail->isSMTP();
	$mail->Host = "smtp.gmail.com";
	$mail->SMTPAuth = true;
	$mail->Username = "icclassifier.main@gmail.com";
	$mail->Password = "admin123!";
	$mail->Port = 465;
	$mail->SMTPSecure = "ssl";

	$mail->isHTML(true);
	$mail->setFrom("icclassifier.main@gmail.com", 'Account Verification');
	$mail->addAddress($email);
	$mail->Subject = 'ICClassifier Account Verification - Please take action';
	$mail->Body = "Hello, $fname,
	<br><br>
	To finish setting up your account, we just need to verify if this email address is yours.
	<br><br>
	To verify your email address, use this code: $verification_key
	<br><br>
	or
	<br><br>
	<a href='http://localhost/icc/user/my-profile?id=1' target='_blank'>Click here</a> to verify your account now.
	<br><br>
	If you didn't make this request, ignore this email. Someone else might have typed your email address by mistake.
	<br><br>
	Thank you,<br>
	ICClassifier
	";

	if ($mail->send()) {

	} 

	else {
		echo $mail->ErrorInfo;
	}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<style type="text/css">
		.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #2F3B4C!important;
		}

		.ttr-material-button:hover {
			background-color: #2F3B4C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
	</style>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #222831;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'dashboard';

					include 'navigation.php';
				?>
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head" style="border-color: #F2A365!important;">Verify <span>Email</span></h2>
				</div>	

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<!-- <div class="wc-title">
								<h4><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Home</h4>
							</div> -->
							<div class="widget-inner">
								<form method="POST" id="verify-form">
									<div class="row">
										<div class="col-lg-6">
											<div class="new-user-list">
												<h3><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h3>

												<div class="form-group row">
													<label class="col-sm-4 col-form-label">Verification Code</label>
													<div class="col-sm-7">
														<input class="form-control" type="text" style="background-color: white;" name="code" id="code" minlength="6" maxlength="6" required>
													</div>
												</div>
											</div>
											<button type="submit" name="verify" class="btn green radius-xl"><i class="ti-unlock"></i><span>&nbsp;&nbsp;VERIFY EMAIL</span></button>
											<div style="padding: 5px;"></div>
										</div>
										<div class="col-lg-6">

										</div>
									</div>
								</form>
								<div id="message"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script type="text/javascript">
			$('#verify-form').submit( function(e) {
				var code = $('#code').val();
				var hashed_code = '<?php echo $hashed_key; ?>';
				var account_id = '<?php echo $account_id; ?>';

				$.ajax({
					url: 'verification.php',
					method: 'POST',
					data: {
						code: code,
						hashed_code: hashed_code,
						account_id: account_id
					},
					success:function(data) {
						$('#message').html(data);
					}
				});

				e.preventDefault();
			});
		</script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>	
		<script type="text/javascript">
			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z. ]+$/ 
					return re.test(keyChar); 
				} 
			}
		</script>
	</body>

</html>