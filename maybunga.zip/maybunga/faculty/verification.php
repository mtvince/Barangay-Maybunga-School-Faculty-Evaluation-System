<?php

	include('../global/model.php');

	if (password_verify($_POST['code'], $_POST['hashed_code'])) {
		$model = new Model();
		$model->verifyAccountPortal($_POST['account_id']);
		echo "<script>window.open('my-profile','_self');</script>";
	}

	else {
		echo '<h5 style="color: red; margin-bottom: 0px;">Wrong Code</h5>';
	}

?>