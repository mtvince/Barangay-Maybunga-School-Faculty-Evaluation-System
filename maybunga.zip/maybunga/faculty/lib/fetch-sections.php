<?php

	session_start();
	include('../../global/model.php');
	$model = new Model();

	$output = '';

	$rows = $model->displaySectionsSelection($_POST['course'], $_POST['year'], 1);

	if (!empty($rows)) {
		foreach ($rows as $row) {
			$output .= '<option value="'.$row['section_id'].'">'.$_POST['course_abv'].' '.$row['year'].'-'.$row['section_name'].'</option>';
		}
	}

	echo $output;

?>