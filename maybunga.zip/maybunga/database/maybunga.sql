-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2022 at 06:04 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maybunga`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `college` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `pword` varchar(70) NOT NULL,
  `status` varchar(50) NOT NULL,
  `verified` int(11) NOT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `access` int(11) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `school_id`, `fname`, `mname`, `lname`, `college`, `year`, `section`, `email`, `contact`, `pword`, `status`, `verified`, `photo`, `access`, `date_added`) VALUES
(1012, '1231231231', 'Llander', 'De Guzman', 'Vidar', '', '3', 'Kalantas', 'dennisllandervidar2@gmail.com', '0914232590111', '$2y$10$Uq8znSVfYUBAiRa83taR/e6KIDHL0dPdLIqbsbQunQrQF/TbRtJse', '2', 0, '1641276967104237889161d3e62703ba7', 0, '2021-12-22 12:24:46'),
(1013, '3434534534534', 'Rajon', 'De Guzman', 'Radiv', 'MAPEH Department', '', '', 'dennisllandervidar@gmail.com', '09142325901111', '$2y$10$Uq8znSVfYUBAiRa83taR/e6KIDHL0dPdLIqbsbQunQrQF/TbRtJse', '2', 0, NULL, 1, '2021-12-22 12:25:36'),
(1015, '11111111111', 'Llander', 'De Guzman', 'Vidar', 'Araling Panlipunan Department', '', '', 'rllopez@ust.edu.ph', '0914232590111', '$2y$10$ewmyX/InOMfl4GpfBEI59.9eO8yknYUvGaVmxK6CTaxCC3ZArto2S', '2', 0, NULL, 1, '2021-12-25 10:55:07'),
(1016, '35255232', 'Llander', 'Rondo', 'Radiv', 'Math Department', '', '', 'lllandera@gmail.com', '09142325901111', '$2y$10$NX7jhjOEMFdt.aRqsJSaSeSloCwUxpDScnYFwkl7UX3hMUCDvdnNy', '2', 0, '1641645269188285363161d984d55605f', 1, '2021-12-25 10:56:18'),
(1019, '13223', 'Dsdsd', 'Ee', 'Sdsdsd', '', '1', 'Kalawang', 'school-webssssite@deped.com', '09142325901111', '$2y$10$9NJLH463e61SkD5BjZe96uSCF1aPyYIvEy56dv/VH6ww4k3cUza1S', '2', 0, NULL, 0, '2021-12-29 00:05:21'),
(1021, '2016678123', 'Jane', 'Perez', 'Santos', 'English Department', '', '', 'janesatos@gmail.com', '09672531283', '$2y$10$7ce5CLJImeu8T6Dnx/czbewCsdNbItalOyPjsq4tXm0f40lAzeeM.', '2', 0, NULL, 1, '2022-01-10 10:38:16'),
(1025, '2020202202', 'Marco', 'Ramos', 'Pangilinan', 'English Department', '', '', 'marcopangilinan@gmail.com', '091236782', '$2y$10$NX7jhjOEMFdt.aRqsJSaSeSloCwUxpDScnYFwkl7UX3hMUCDvdnNy', '2', 0, NULL, 1, '2022-01-10 11:21:31'),
(1026, '2018200506', 'Iris', 'Ramos', 'Ferrera', '', '3', 'Kalantas', 'iris@gmail.com', '09152171627', '$2y$10$NX7jhjOEMFdt.aRqsJSaSeSloCwUxpDScnYFwkl7UX3hMUCDvdnNy', '2', 0, NULL, 0, '2022-01-10 12:06:12'),
(1027, '2018200678', 'Abigail', 'Brosas', 'Rabutin', '', '3', 'Kalantas', 'abglrbtn24@gmail.com', '09675233784', '$2y$10$NX7jhjOEMFdt.aRqsJSaSeSloCwUxpDScnYFwkl7UX3hMUCDvdnNy', '2', 0, NULL, 0, '2022-01-29 11:51:01'),
(1030, '123456', 'Dennis Llander', 'Vidar', 'Vidar', 'Filipino Department', '', '', 'dennisllandervidar@gmail.com2d', '09342342', '$2y$10$CMPQZSdZycP.wBKV32No6ufCSFdD/5UgiyxtDxNXnv241U7OmldEK', '2', 0, NULL, 1, '2022-11-22 22:13:04'),
(1032, '23534645', 'Llander', 'De Guzman', 'Vidar', 'English Department', '', '', 'admin@gmail.comdwdaw', '09154123108', '$2y$10$exgHpL4mHsukTOr/bx8hF.vj8buXAV.QwRqG/Gksgnd2N8DMnG22C', '2', 0, NULL, 1, '2022-11-24 17:19:20'),
(1033, '213', 'Jam', 'Allaine', 'Yasona', 'Filipino Department', '', '', 'yasona@faculty.com', '09123245512', '$2y$10$kVAq9ysqlnMdat0OXbzw0u0rGMSOs4SqGOspWzQovo3KKcco12Myy', '1', 0, NULL, 1, '2022-12-06 23:57:59'),
(1034, '192837465', 'Von', 'Patrick', 'Suner', '', '6', 'Mabalacat', 'von@student.com', '09884472231', '$2y$10$n0.w7AeOFxPxut0/1yIAZuv8EE91z7Ln7YskR/wC5TiYaRNg3pIs.', '1', 0, NULL, 0, '2022-12-07 00:00:21'),
(1035, '192837475', 'Emman', 'Sonyo', 'Abaja', '', '5', 'Alaminos', 'emman@student.com', '09884724651', '$2y$10$iNSCtQHDhS9r/dq5OKNp..RLHW8aT7jZXeaIEktiue9uSQFPCpSoC', '1', 0, NULL, 0, '2022-12-07 00:02:49'),
(1036, '322', 'Yvonne', 'Claire', 'De Leon', 'English Department', '', '', 'deleon@faculty.com', '09986542314', '$2y$10$0yOx9mZf7I35sX4BF1Iu0OlU76ioQQYH74Opx1YbKQyvQ4c.bwiH6', '1', 0, NULL, 1, '2022-12-07 01:45:58'),
(1037, '231', 'Leonil', 'Bondoc', 'Ignacio', 'Science Department', '', '', 'ignacio@faculty.com', '09962346755', '$2y$10$.w0Korc/qYBHLlyYtLkFTeJmSSjcVeUsgBs42TeV4EpAO2hTb22/u', '1', 0, NULL, 1, '2022-12-07 01:47:28'),
(1038, '133', 'Joanne', 'Basac', 'Maniling', 'Math Department', '', '', 'maniling@faculty.com', '09964674876', '$2y$10$jzt0LJd2nGiMEE9a712qcOPnG8Bs5wTaEDOIDsgt.dw024Wf5J5JC', '1', 0, NULL, 1, '2022-12-07 01:49:16'),
(1039, '247', 'Eumi', 'Laine', 'Santos', 'Araling Panlipunan Department', '', '', 'santos@faculty.com', '09945922346', '$2y$10$852DGNM/wReV2y5ZeziLauk15L8SLUt30co4J0LtKGEDvl/v9wPxy', '1', 0, NULL, 1, '2022-12-07 01:51:20'),
(1040, '19234562', 'Johance', 'Pasco', 'Gasacao', '', '4', 'Batanes', 'gasacao@student.com', '123422345', '$2y$10$uIOzrBTog7hyNiKBsQYHle7rxwhEQq58bvSBpz2LipYcfbcMewjj2', '1', 0, NULL, 0, '2022-12-07 01:53:20'),
(1041, '23141234', 'Kris', 'Anne', 'Jore', '', '3', 'San Fernando', 'jore@student.com', '844564573', '$2y$10$xHWT1tE3pUihxAsWyZjo3.jeQsTTuPTYXnO9.UWKe2ipGJMH/5Vqq', '1', 0, NULL, 0, '2022-12-07 01:54:32'),
(1042, '31425685', 'Rafael', 'Wisonoc', 'Ramiro', '', '5', 'Apalit', 'ramiro@faculty.com', '12315354734', '$2y$10$DO.5EcqKrDt8s.LOMQxAmOYjo8uFuPa2j3OUHHHoaas.fmluKzQ/O', '1', 0, NULL, 0, '2022-12-07 01:56:17'),
(1043, '23124578', 'John Anthony', 'Junio', 'Leal', '', '6', 'Manila', 'leal@student.com', '09876556332', '$2y$10$hbLjVOuYpWwj07preqBl7OxFUKp95PL8ay/fpm4BMB9xrLiJ.wZCe', '1', 0, NULL, 0, '2022-12-07 01:58:19'),
(1044, '23125685', 'Andrei', 'Rebadeo', 'Sabandal', '', '5', 'Alaminos', 'sabandal@student.com', '09664434527', '$2y$10$aIvAIM8ODiagcQz7FAJID.ZkokIWmP6Q1dOTaFWC5vBIeG4OwwG7K', '1', 0, NULL, 0, '2022-12-07 01:59:38'),
(1045, '22123513', 'Emil', 'Abad', 'Prinsesa', '', '4', 'Batac', 'prinsesa@student.com', '09972221457', '$2y$10$mwM.HfH2rU0GJ5ZZFLLYAOa4AWAizbkTO54ZAnaMiXYDuj.m17IiO', '1', 0, NULL, 0, '2022-12-07 02:01:07'),
(1046, '232579678', 'Monica May', 'Petero', 'Revadavia', '', '3', 'San Juan', 'may@student.com', '4565463235', '$2y$10$41sceQEv/27qUq6kmuSJY.XGuaZiwglVHa39YywxuSsktLyaB9Ojy', '1', 0, NULL, 0, '2022-12-07 02:03:43'),
(1047, '56734589', 'Khimberly', 'Galayo', 'Datiles', '', '3', 'San Fernando', 'galayo@student.com', '09778567453', '$2y$10$lsmxZJN2DMOa58sXoFDpyupLyYPU.Tl1GTcFORUwRFVG331WAxXgm', '1', 0, NULL, 0, '2022-12-07 02:04:49');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pword` varchar(65) NOT NULL,
  `affiliation` varchar(100) NOT NULL,
  `photo` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `uname`, `pword`, `affiliation`, `photo`) VALUES
(1, 'Juan Dela Cruz', 'admin@gmail.com', '$2y$10$Uq8znSVfYUBAiRa83taR/e6KIDHL0dPdLIqbsbQunQrQF/TbRtJse', '09574678195', '163937657095737517761b6e6ba6a861');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `instructor_subject_id` int(11) NOT NULL,
  `q1` int(11) NOT NULL,
  `q2` int(11) NOT NULL,
  `q3` int(11) NOT NULL,
  `q4` int(11) NOT NULL,
  `q5` int(11) NOT NULL,
  `q6` int(11) NOT NULL,
  `q7` int(11) NOT NULL,
  `q8` int(11) NOT NULL,
  `q9` int(11) NOT NULL,
  `q10` int(11) NOT NULL,
  `q11` int(11) NOT NULL,
  `q12` int(11) NOT NULL,
  `q13` int(11) NOT NULL,
  `q14` int(11) NOT NULL,
  `q15` int(11) NOT NULL,
  `q16` int(11) NOT NULL,
  `q17` int(11) NOT NULL,
  `q18` int(11) NOT NULL,
  `q19` int(11) NOT NULL,
  `q20` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `instructor_id`, `student_id`, `semester_id`, `semester`, `instructor_subject_id`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`, `q11`, `q12`, `q13`, `q14`, `q15`, `q16`, `q17`, `q18`, `q19`, `q20`) VALUES
(14, 1032, 1012, 3, 'Fourth Quarter', 13, 3, 3, 2, 4, 2, 3, 4, 3, 4, 5, 3, 2, 2, 3, 4, 5, 4, 3, 2, 1),
(15, 1033, 1035, 3, 'Fourth Quarter', 16, 5, 3, 3, 4, 4, 3, 2, 3, 4, 2, 1, 4, 2, 1, 2, 3, 4, 5, 4, 3),
(16, 1033, 1034, 3, 'Fourth Quarter', 15, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_abv` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `course_abv`, `status`) VALUES
(24, 'Bachelor of Science in Business Administration', 'BSBA', 1),
(25, 'Bachelor of Elementary Education', 'BEED', 1),
(26, 'Bachelor of Secondary Education Major in English Minor in Mandarin', 'BSED - ENGLISH', 1),
(27, 'Bachelor of Science in Secondary Education Major in Mathematics', 'BSED - MATHEMATICS', 1),
(28, 'Bachelor of Science in Secondary Education major in Social Studies', 'BSED - SOCIAL STUDIES', 1),
(29, 'Bachelor of Science in Secondary Education Major in Science', 'BSED - SCIENCE', 1),
(30, 'Bachelor of Science in Physical Education', 'BSED - PE', 1),
(31, 'Bachelor of Early Childhood Education', 'BECED', 1),
(32, 'Bachelor of Technology and Livelihood Education major in Home Economics', 'BTLED - HE', 1),
(33, 'Bachelor of Technical-Vocational Teacher Education major in Food and Service Management ', 'BTVTED - FSM', 1),
(34, ' Bachelor of Science in Computer Engineering', 'BS CPE', 1),
(35, 'Bachelor of Science in Industrial Engineering', 'BSIE', 1),
(36, 'Bachelor of Science in Information Technology', 'BSIT', 1),
(37, ' Bachelor of Industrial Technology major in Food Technology', 'BIT-FT', 1),
(38, 'Bachelor of Industrial Technology major in Automotive Technology', 'BIT-AT', 1),
(39, 'Bachelor in Industrial Technology major in Drafting Technology', 'BIT-DT', 1),
(40, 'Bachelor of Industrial Technology Major in Electrical Technology', 'BIT-ET', 1),
(41, 'Bachelor of Industrial Technology Major in Computer Technology', 'BIT-CT', 1),
(42, 'Bachelor of Science in Financial Management', 'BSFM', 1),
(43, 'Bachelor of Science in Entrepreneurship', 'BSE', 1),
(44, 'Bachelor of Science in Marketing Management', 'BSMM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(200) NOT NULL,
  `dept_abv` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`dept_id`, `dept_name`, `dept_abv`, `status`) VALUES
(1, 'English Department', 'ENG', 1),
(2, 'Filipino Department', 'FIL', 1),
(3, 'Science Department', 'SCI', 1),
(4, 'Math Department', 'MATH', 1),
(5, 'Araling Panlipunan Department', 'AP', 1),
(6, 'Edukasyon sa Pagpapakatao Department', 'ESP', 1),
(7, 'MAPEH Department', 'MAPEH', 1),
(8, 'Edukasyong Pantahanan at Pangkabuhayan Department', 'EPP', 1),
(9, 'Technology and Livelihood Education Department', 'TLE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `instructor_subject`
--

CREATE TABLE `instructor_subject` (
  `id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor_subject`
--

INSERT INTO `instructor_subject` (`id`, `instructor_id`, `course_id`, `section_id`, `subject_id`, `semester_id`) VALUES
(12, 1030, 0, 132, 176, 3),
(13, 1032, 0, 132, 176, 3),
(15, 1033, 0, 133, 177, 3),
(16, 1033, 0, 134, 178, 3),
(17, 1038, 0, 142, 199, 7);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `instructor_subject_id` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `semester` varchar(50) DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `answer_id`, `instructor_id`, `student_id`, `instructor_subject_id`, `message`, `semester_id`, `semester`, `date_added`, `status`) VALUES
(10, 14, 1032, 1012, 13, 'TESTING', 3, 'Fourth Quarter', '2022-11-24 19:18:00', 1),
(11, 15, 1033, 1035, 16, 'Thanks!', 3, 'Fourth Quarter', '2022-12-07 00:05:31', 1),
(12, 16, 1033, 1034, 15, 'Meaningful', 3, 'Fourth Quarter', '2022-12-07 00:08:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `on_off`
--

CREATE TABLE `on_off` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `on_off`
--

INSERT INTO `on_off` (`id`, `status`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questionares`
--

CREATE TABLE `questionares` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `commitment` varchar(200) NOT NULL,
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questionares`
--

INSERT INTO `questionares` (`id`, `number`, `commitment`, `type`, `status`) VALUES
(1, 1, 'Recognizes student’s strengths and weaknesses while showing concern to them as a person.', 1, 1),
(2, 2, 'Participates in cooperative efforts to address students’ or class problems.', 1, 1),
(3, 3, 'Makes himself/herself available for consultation.', 1, 1),
(4, 4, 'He/she is approachable even in the virtual space.', 1, 1),
(5, 5, 'Provides supplemental resources to facilitate teaching-learning activities.', 1, 1),
(6, 1, 'Creates appropriate teaching strategies that allow students to learn concepts they need to understand.', 3, 1),
(7, 2, 'Stimulates interactive learning by encouraging students to raise problems and present solutions.', 3, 1),
(8, 3, 'Provides online/offline exercises which develop creative and critical thinking among students.', 3, 1),
(9, 4, 'Enhances student’s self-esteem through proper recognition of their abilities.', 3, 1),
(10, 5, 'Accomplishes the objectives of the course through the lessons delivered.', 3, 1),
(11, 1, 'Explains the subject matter without completely relying on the prescribed modules/instructional materials.', 2, 1),
(12, 2, 'Explains the subject matter with depth in a clear and organized manner.', 2, 1),
(13, 3, 'Relates the subject matter to previous and other related topics.', 2, 1),
(14, 4, 'Integrates current and relevant developments to supplement information in the modules/instructional materials.', 2, 1),
(15, 5, 'Shows confidence in the delivery of lectures and conduct of interactive discussions.', 2, 1),
(16, 1, 'Explains the syllabus at the beginning of the semester and stimulates the student’s interest to learn more about the subject matter.', 4, 1),
(17, 5, 'Uses varied teaching methodologies to enhance attainment of the course learning objectives.', 4, 1),
(18, 2, 'Monitors student’s learning regularly and adapts other teaching methods if student performance is below satisfactory.', 4, 1),
(19, 3, 'Designs and implements learning conditions and experiences that promote healthy exchange of ideas and/or discourses.', 4, 1),
(20, 4, 'Summarizes major points in the lesson and maintains an atmosphere conductive to learning.', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `section_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `year` varchar(100) NOT NULL,
  `section_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`section_id`, `course_id`, `year`, `section_name`, `status`) VALUES
(131, 0, '1', 'Kalawang', 2),
(132, 0, '3', 'Kalantas', 2),
(133, 0, '6', 'Mabalacat', 1),
(134, 0, '5', 'Alaminos', 1),
(135, 0, '4', 'Batac', 1),
(136, 0, '3', 'San Juan', 1),
(137, 0, '2', 'Laoag', 2),
(138, 0, '1', 'Cadayan', 2),
(139, 0, '2', 'Cagayan', 1),
(140, 0, '2', 'Claveria', 1),
(141, 0, '2', 'Cadayan', 1),
(142, 0, '3', 'San Fernando', 1),
(143, 0, '4', 'Batanes', 1),
(144, 0, '5', 'Angeles', 1),
(145, 0, '5', 'Apalit', 1),
(146, 0, '6', 'Manila', 1),
(147, 0, '1', 'Narvacan', 1),
(148, 0, '1', 'Nueva Vizcaya', 1),
(149, 0, '0', 'Paoay', 1),
(150, 0, '0', 'Pasiquin', 1),
(151, 0, '0', 'Pagudpud', 1);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `sem_id` int(11) NOT NULL,
  `syear` varchar(50) NOT NULL,
  `sem` varchar(50) NOT NULL,
  `date_added` datetime NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`sem_id`, `syear`, `sem`, `date_added`, `status`) VALUES
(1, '2019-2020', 'Fourth Quarter', '2021-12-11 05:38:13', 1),
(2, '2020-2021', 'Second Quarter', '2021-12-11 05:38:13', 1),
(3, '2021-2022', 'Fourth Quarter', '2022-01-03 13:21:18', 0),
(7, '2022-2023', 'First Quarter', '2022-12-07 00:30:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject_code` varchar(50) NOT NULL,
  `subject_title` varchar(100) NOT NULL,
  `year` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `course_id`, `subject_code`, `subject_title`, `year`, `semester`, `status`) VALUES
(176, 0, 'CodeT', 'Title', '3', '', 2),
(177, 0, '06F', 'Filipino', '6', '', 1),
(178, 0, '05F', 'Filipino', '5', '', 1),
(179, 0, '04F', 'Filipino', '4', '', 1),
(180, 0, '03F', 'Filipino', '3', '', 1),
(181, 0, '02F', 'Filipino', '2', '', 1),
(182, 0, '01F', 'Filipino', '1', '', 1),
(183, 0, '0KR', 'Reading', '0', '', 1),
(184, 0, '06E', 'English', '6', '', 1),
(185, 0, '05E', 'English', '5', '', 1),
(186, 0, '04E', 'English', '4', '', 1),
(187, 0, '03E', 'English', '3', '', 1),
(188, 0, '02E', 'English', '2', '', 1),
(189, 0, '01E', 'English', '1', '', 1),
(190, 0, '0KW', 'Writing', '0', '', 1),
(191, 0, '01S', 'Science', '1', '', 1),
(192, 0, '02S', 'Science', '2', '', 1),
(193, 0, '03S', 'Science', '3', '', 1),
(194, 0, '04S', 'Science', '4', '', 1),
(195, 0, '05S', 'Science', '5', '', 1),
(196, 0, '06S', 'Science', '6', '', 1),
(197, 0, '01M', 'Math', '1', '', 1),
(198, 0, '02M', 'Math', '2', '', 1),
(199, 0, '03M', 'Math', '3', '', 1),
(200, 0, '04M', 'Math', '4', '', 1),
(201, 0, '05M', 'Math', '5', '', 1),
(202, 0, '06M', 'Math', '6', '', 1),
(203, 0, '01AP', 'Araling Panlipunan', '1', '', 1),
(204, 0, '02AP', 'Araling Panlipunan', '2', '', 1),
(205, 0, '03AP', 'Araling Panlipunan', '3', '', 1),
(206, 0, '04AP', 'Araling Panlipunan', '4', '', 1),
(207, 0, '05AP', 'Araling Panlipunan', '5', '', 1),
(208, 0, '06AP', 'Araling Panlipunan', '6', '', 1),
(209, 0, 'O1EPP', 'Edukasyon sa Pagpapakatao', '1', '', 1),
(210, 0, 'O2EPP', 'Edukasyon sa Pagpapakatao', '2', '', 1),
(211, 0, 'O3EPP', 'Edukasyon sa Pagpapakatao', '3', '', 1),
(212, 0, '04EPP', 'Edukasyon sa Pagpapakatao', '4', '', 1),
(213, 0, '05EPP', 'Edukasyon sa Pagpapakatao', '5', '', 1),
(214, 0, '06EPP', 'Edukasyon sa Pagpapakatao', '6', '', 1),
(215, 0, '01MAPEH', 'Music, Arts, PE, Health', '1', '', 1),
(216, 0, '02MAPEH', 'Music, Arts, PE, Health', '2', '', 1),
(217, 0, '03MAPEH', 'Music, Arts, PE, Health', '3', '', 1),
(218, 0, '04MAPEH', 'Music, Arts, PE, Health', '4', '', 1),
(219, 0, '05MAPEH', 'Music, Arts, PE, Health', '5', '', 1),
(220, 0, '06MAPEH', 'Music, Arts, PE, Health', '6', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `school_id` (`school_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `course_name` (`course_name`,`course_abv`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `dept_name` (`dept_name`,`dept_abv`);

--
-- Indexes for table `instructor_subject`
--
ALTER TABLE `instructor_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `on_off`
--
ALTER TABLE `on_off`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questionares`
--
ALTER TABLE `questionares`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`sem_id`),
  ADD UNIQUE KEY `syear` (`syear`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1048;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `instructor_subject`
--
ALTER TABLE `instructor_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `on_off`
--
ALTER TABLE `on_off`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `questionares`
--
ALTER TABLE `questionares`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `sem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
