<?php
	session_start();
	include('../global/model.php');
	include('department.php');

	$account_id = isset($_GET['id']) ? $_GET['id'] : '';
	$account = $model->displayAccountProfile($account_id);
	if (!empty($account)) {
		foreach ($account as $row) {
			$school_id = $row['school_id'];
			$fname = strtoupper($row['fname']);
			$mname = strtoupper($row['mname']);
			$lname = strtoupper($row['lname']);
			$email = strtolower($row['email']);
			$college = $row['college'];
			$year = $row['year'];
			$section = $row['section'];
			$contact = $row['contact'];
			$access = $row['access'];
			$date_added = date('M d, Y g:i A', strtotime($row['date_added']));

			if ($row['photo'] == "") {
				$photo2 = "default";
			}
			else {
				$photo2 = $row['photo'];
			}

			if ($row['verified'] == 0) {
				$ver = "<span style='color: red;'>NOT VERIFIED</span>";
			}
			else {
				$ver = "<span style='color: green;'>VERIFIED</span>";
			}
		}
	}

	$show1 = "";
	$show0 = "";
	if ($access == 1) {
		$show1 = "show";
		$label = "Faculty";
	}
	elseif ($access == 0) {
		$show0 = "show";
		$label = "Student";
	}
	else { 
		echo "<script>window.open('index','_self');</script>";
	}

	if ($year == 1) {
		$year2 = "First Year";
	}
	elseif ($year == 2) {
		$year2 = "Second Year";
	}
	elseif ($year == 3) {
		$year2 = "Third Year";
	}
	elseif ($year == 4) {
		$year2 = "Fourth Year";
	}
	elseif ($year == 5) {
		$year2 = "Fifth Year";
	}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'students';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head"><?php echo $label; ?><span> Profile</span></h2>
				</div>	
				
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<div class="row">
									<div class="col-lg-10">
										<div class="new-user-list">
											<div class="row">
												<div class="col-lg-3">
													<img src="../assets/images/profile-img/<?php echo $photo2; ?>.jpg" alt="User" style="width: 200px; height: 200px; border-radius: 50%;object-fit: cover;border: 2px solid #E2E2E2;">
												</div>
												<div class="col-lg-9">
													<h3><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h3>
													<div class="row">
														<div class="col-lg-2">
															<h6>LRN:</h6>
															<?php if ($access == 1) { ?>
															<h6>Department:</h6>
															<?php } elseif ($access == 0) { ?>
															<h6>Year:</h6>
															<h6>Section:</h6>
															<?php } ?>
															<h6>Contact:</h6>
															<h6>Email:</h6>
															<!-- <h6>Status:</h6> -->
														</div>
														<?PHP 
														if ($year == "0") {
															$grade_level = "Kindergarten";
														}
														else if ($year == "1") {
															$grade_level = "Grade 1";
														}
														else if ($year == "2") {
															$grade_level = "Grade 2";
														}
														else if ($year == "3") {
															$grade_level = "Grade 3";
														}
														else if ($year == "4") {
															$grade_level = "Grade 4";
														}
														else if ($year == "5") {
															$grade_level = "Grade 5";
														}
														else if ($year == "6") {
															$grade_level = "Grade 6";
														}
														else {
															$grade_level = "Error";
														}
														
														?>
														<div class="col-lg-7">
															<h6><?php echo $school_id; ?></h6>
															<?php if ($access == 1) { ?>
															<h6><?php echo $college; ?></h6>
															<?php } elseif ($access == 0) { ?>
															<h6><?php echo $year2; ?></h6>
															<h6><?php echo $section; ?></h6>
															<?php } ?>
															<h6><?php echo $contact; ?></h6>
															<h6><?php echo $email; ?></h6>
															<!-- <h6><?php echo $ver; ?></h6> -->
														</div>
													</div>
												</div>
											</div>
										</div>
										<hr>
										<!-- <a href="update-profile" class="btn green radius-xl"><i class="ti-marker-alt"></i><span>&nbsp;&nbsp;UPDATE MY PROFILE</span></a>&nbsp;&nbsp;
										<a href="change-password" class="btn blue radius-xl"><i class="ti-lock"></i><span>&nbsp;&nbsp;UPDATE PASSWORD</span></a> -->
										<div style="padding: 5px;"></div>
									</div>
									<div class="col-lg-2">

									</div>
									<div class="col-lg-12">
										<div class="orders-list">
								<h4><?php echo strtoupper($csy); ?> | <?php echo strtoupper($csm); ?></h4>
								<?php

									// $rows = $model->fetchCourseID($college);
									// if (!empty($rows)) { 
									// 	foreach ($rows as $row) {
									// 		$course_id = $row['course_id'];
									// 	}
									// }

									$rows = $model->fetchSectionID($year, $section);
									if (!empty($rows)) { 
										foreach ($rows as $row) {
											$section_idd = $row['section_id'];
										}
									}

									$previous_rows = $model->displaySubjectsFiltered(1, $year);
									if (!empty($previous_rows)) { 
										foreach ($previous_rows as $row) {

										$photox = "default";
										$name = "";
										$evaluation = '<center><a href="" class="btn button-sm red">Form Unavailable</a></center> ';
										$modal = '';

										$rowsy = $model->displaySubjectInstructor($row['subject_id'], $section_idd, $csid);
										if (!empty($rowsy)) {

											foreach ($rowsy as $rowy) {
												$instructor_subject_id = $rowy['aid'];
												$instructor_id = $rowy['instructor_id'];
												$i_fname = strtoupper($rowy['fname']);
												$i_mname = strtoupper($rowy['mname']);
												$i_lname = strtoupper($rowy['lname']);
												$i_email = strtolower($rowy['email']);
												$i_college = $rowy['college'];
												$i_contact = $rowy['contact'];

												if ($rowy['photo'] == "") {
													$photox = "default";
												}
												else {
													$photox = $rowy['photo'];
												}

												$name = "".$i_fname." ".$i_lname."";
												$evaluation = '<a href="evaluate?id='.$rowy['aid'].'&subject='.$row['subject_id'].'" class="btn button-sm yellow">Evaluate Instructor</a>';
												$modal = 'data-toggle="modal"';

												// echo $account_id;
												// echo "hr";
												// echo $instructor_id;
												// echo "hr";
												// echo $instructor_subject_id;

												$rowsyx = $model->evaluatedChecker($account_id, $instructor_id, $instructor_subject_id);
												if (!empty($rowsyx)) {
													foreach ($rowsyx as $rowyx) {
														$evaluation = '<center><a href="" class="btn button-sm green">Evaluation Finished</a></center> ';
														$modal = 'data-toggle="modal"';
													}
												}

											}
										}
									
										if ($name == "") { $name = "NO INSTRUCTOR PROFILE"; }
								?>
								<ul>
									<li>
										<span class="orders-title">
											<h4><?php echo $row['subject_code']; ?> | <?php echo $row['subject_title']; ?><br><small><a href="" <?php echo $modal; ?> data-target="#profile-<?php echo $row['subject_id']; ?>"><img src="../assets/images/profile-img/<?php echo $photox; ?>.jpg" alt="User" style="width: 30px; height: 30px; border-radius: 50%;object-fit: cover;">&nbsp;<?php echo ucwords(strtolower($name)); ?></a></small></h4>
										</span>
										<span class="orders-btn">
											<!-- <center><?php echo $evaluation; ?></center>  -->
										</span>
									</li>
								</ul><br>

											<div id="profile-<?php echo $row['subject_id']; ?>" class="modal fade" role="dialog">
												<form class="edit-profile m-b30" method="POST">
													<div class="modal-dialog modal-md">
														<div class="modal-content">
															<div class="modal-header">
																<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Faculty Profile</h4>
																<button type="button" class="close" data-dismiss="modal">&times;</button>
															</div>
															<div class="modal-body">
																<div class="row">
																	<input type="hidden" name="user_id" value="<?php echo $uid; ?>">
																	<div class="col-lg-1"></div>
																	<div class="col-lg-10">
																		<center><img src="../assets/images/profile-img/<?php echo $photox; ?>.jpg" alt="User" style="width: 120px; height: 120px; border-radius: 50%;object-fit: cover;"><hr>
																		<h4><?php echo ucwords(strtolower($i_fname)); ?> <?php echo ucwords(strtolower($i_mname)); ?> <?php echo ucwords(strtolower($i_lname)); ?></h4>
																		<h6><?php echo $i_college; ?></h6>
																		<h6><?php echo $i_contact; ?></h6>
																		<h6><?php echo $i_email; ?></h6>
																		</center>
																	</div>
																</div>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</form>
											</div>
								<?php 
										}
									}
									else {
										echo "NO DATA";
									}
								?>
								</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>	
		<script type="text/javascript">
			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z. ]+$/ 
					return re.test(keyChar); 
				} 
			}
		</script>
	</body>

</html>