<?php
	session_start();
	include('../global/model.php');
	include('department.php');

	$account_id = isset($_GET['id']) ? $_GET['id'] : '';
	$account = $model->displayAccountProfile($account_id);
	if (!empty($account)) {
		foreach ($account as $row) {
			$school_id = $row['school_id'];
			$fname = strtoupper($row['fname']);
			$mname = strtoupper($row['mname']);
			$lname = strtoupper($row['lname']);
			$email = strtolower($row['email']);
			$college = $row['college'];
			$year = $row['year'];
			$section = $row['section'];
			$contact = $row['contact'];
			$access = $row['access'];
			$date_added = date('M d, Y g:i A', strtotime($row['date_added']));

			if ($row['photo'] == "") {
				$photo2 = "default";
			}
			else {
				$photo2 = $row['photo'];
			}

			if ($row['verified'] == 0) {
				$ver = "<span style='color: red;'>NOT VERIFIED</span>";
			}
			else {
				$ver = "<span style='color: green;'>VERIFIED</span>";
			}
		}
	}

	$show1 = "";
	$show0 = "";
	if ($access == 1) {
		$show1 = "show";
		$label = "Teacher";
	}
	elseif ($access == 0) {
		$show0 = "show";
		$label = "Student";
	}
	else { 
		echo "<script>window.open('index','_self');</script>";
	}

	if ($year == 1) {
		$year2 = "First Year";
	}
	elseif ($year == 2) {
		$year2 = "Second Year";
	}
	elseif ($year == 3) {
		$year2 = "Third Year";
	}
	elseif ($year == 4) {
		$year2 = "Fourth Year";
	}
	elseif ($year == 5) {
		$year2 = "Fifth Year";
	}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />

		<meta name="description" content="" />

		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<meta name="format-detection" content="telephone=no">

		<link rel="icon" href="../assets/images/icon.png" type="image/x-icon" />
		<link rel="shortcut icon" type="image/x-icon" href="../assets/images/icon.png" />

		<title>Faculty Evaluation System | Maybunga Elementary School</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/assets.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/vendors/calendar/fullcalendar.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/typography.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/shortcodes/shortcodes.css">

		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="../dashboard/assets/css/dashboard.css">
		<link class="skin" rel="stylesheet" type="text/css" href="../dashboard/assets/css/color/color-1.css">
	</head>
	<style type="text/css">
			.btn.dropdown-toggle.btn-default:hover {
			color: #000!important;
		}

		.btn.dropdown-toggle.btn-default:focus {
			color: #000!important;
		}

		tbody tr:hover {
			background-color: #d4d4d4;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}

		.ttr-sidebar-navi ul li.show > a {
			background-color: #C8A23C!important;
		}

		.ttr-material-button:hover {
			background-color: #C8A23C!important;
		}

		.ttr-label, .ttr-icon > i {
			color: white;
		}
		.widget-card .icon {
			position: absolute;
			top: auto;
			bottom: -20px;
			right: 5px;
			z-index: 0;
			font-size: 65px;
			color: rgba(0, 0, 0, 0.15);
		}
		.borderless td, .borderless th {
		    border: none;
		}
		</style>
	<body class="ttr-opened-sidebar ttr-pinned-sidebar" style="background-color: #F3F3F3;">

		<?php include 'navbar.php'; ?>

		<div class="ttr-sidebar" style="background-color: #2861AB;">
			<div class="ttr-sidebar-wrapper content-scroll">
				
				<?php 
					include 'sidebar.php';

					$page = 'faculty';

					include 'navigation.php';
				?>
				
			</div>
		</div>
		<main class="ttr-wrapper" style="background-color: #F3F3F3;">
			<div class="container-fluid">
				<div class="heading-bx left">
					<h2 class="title-head"><?php echo $label; ?><span> Profile</span></h2>
				</div>	
				
				<?php include 'widget.php'; ?>

				<div class="row">
					<div class="col-lg-12 m-b30">
						<div class="widget-box">
							<div class="widget-inner">
								<div class="row">
									<div class="col-lg-10">
										<div class="new-user-list">
											<div class="row">
												<div class="col-lg-3">
													<img src="../assets/images/profile-img/<?php echo $photo2; ?>.jpg" alt="User" style="width: 200px; height: 200px; border-radius: 50%;object-fit: cover;border: 2px solid #E2E2E2;">
												</div>
												<div class="col-lg-9">
													<h3><?php echo ucwords(strtolower($fname)); ?> <?php echo ucwords(strtolower($mname)); ?> <?php echo ucwords(strtolower($lname)); ?></h3>
													<div class="row">
														<div class="col-lg-2">
															<h6>School ID:</h6>
															<?php if ($access == 1) { ?>
															<h6>Department:</h6>
															<?php } elseif ($access == 0) { ?>
															<h6>Course:</h6>
															<h6>Year:</h6>
															<h6>Section:</h6>
															<?php } ?>
															<h6>Contact:</h6>
															<h6>Email:</h6>
															<!-- <h6>Status:</h6> -->
														</div>
														<div class="col-lg-7">
															<h6><?php echo $school_id; ?></h6>
															<?php if ($access == 1) { ?>
															<h6><?php echo $college; ?></h6>
															<?php } elseif ($access == 0) { ?>
															<h6><?php echo $college; ?></h6>
															<h6><?php echo $year2; ?></h6>
															<h6><?php echo $year; ?>-<?php echo $section; ?></h6>
															<?php } ?>
															<h6><?php echo $contact; ?></h6>
															<h6><?php echo $email; ?></h6>
															<!-- <h6><?php echo $ver; ?></h6> -->
														</div>
													</div>
												</div>
											</div>
										</div>
										<hr>

										<!-- <a href="update-profile" class="btn green radius-xl"><i class="ti-marker-alt"></i><span>&nbsp;&nbsp;UPDATE MY PROFILE</span></a>&nbsp;&nbsp;
										<a href="change-password" class="btn blue radius-xl"><i class="ti-lock"></i><span>&nbsp;&nbsp;UPDATE PASSWORD</span></a> -->
										<div style="padding: 5px;"></div>
									</div>
									<div class="col-lg-2">

									</div>
									<div class="col-lg-12">
										<a href="" data-toggle="modal" data-target="#add-subj" class="btn green radius-xl" style="float: right;"><i class="fa fa-plus" style="font-size: 14px;"></i><span>&nbsp;&nbsp;ADD SUBJECT</span></a><br><br>
								<div class="orders-list">
								<h4><?php echo strtoupper($csy); ?> | <?php echo strtoupper($csm); ?></h4>
								<?php
									$previous_rows = $model->displayInstructorSubjects($account_id, $csid);
									if (!empty($previous_rows)) { 
										foreach ($previous_rows as $row) {

										$rowsy = $model->count_student_section($row['year'], $row['section_name']);
										if (!empty($rowsy)) {
											foreach ($rowsy as $rowy) {
												$cstudentsection = $rowy['cstudentsection'];
											}
										}
										
										if ($cstudentsection == "") { $cstudentsection = 0; }
										
										if ($row['year'] == "0") {
															$grade_level = "Kindergarten";
														}
														else if ($row['year'] == "1") {
															$grade_level = "Grade 1";
														}
														else if ($row['year'] == "2") {
															$grade_level = "Grade 2";
														}
														else if ($row['year'] == "3") {
															$grade_level = "Grade 3";
														}
														else if ($row['year'] == "4") {
															$grade_level = "Grade 4";
														}
														else if ($row['year'] == "5") {
															$grade_level = "Grade 5";
														}
														else if ($row['year'] == "6") {
															$grade_level = "Grade 6";
														}
														else {
															$grade_level = "Error";
														}
								?>
								<ul>
									<li>
										<span class="orders-title">
											<h4><?php echo $grade_level; ?>-<?php echo $row['section_name']; ?><br><small><?php echo strtoupper($row['subject_code']); ?> |  <?php echo strtoupper($row['subject_title']); ?></small></h4>
										</span>
										<span class="orders-btn">
											<center><a href="section-students?year=<?php echo $row['year']; ?>&section=<?php echo $row['section_name']; ?>" class="btn button-sm yellow">View Students (<?php echo $cstudentsection; ?>)</a></center> 
										</span>
									</li>
								</ul><br>
								<?php 
										}
									}
									else {
										echo "NO DATA";
									}
								?>
								</div>
								<div id="add-subj" class="modal fade" role="dialog">
									<form class="edit-profile m-b30" method="POST">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<h4 class="modal-title"><img src="../assets/images/icon.png" style="width: 30px; height: 30px;">&nbsp;Add Subject</h4>
													<button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>
												<div class="modal-body">
													<div class="row">
														<div class="form-group col-12">
															<label class="col-form-label">Grade Level</label>
															<select class="form-control" name="year" id="year" required>
															    <option value="0">Kindergarten</option>
																<option value="1">Grade 1</option>
																<option value="2">Grade 2</option>
																<option value="3">Grade 3</option>
																<option value="4">Grade 4</option>
																<option value="5">Grade 5</option>
																<option value="6">Grade 6</option>
															</select>
														</div>
														<div class="form-group col-12">
															<label class="col-form-label">School Year</label>
															<input type="text" class="form-control" name="sem" id="semester" value="<?php echo strtoupper($csy); ?> | <?php echo $csm; ?>" readonly> 
														</div>
														<div class="form-group col-12">
															<label class="col-form-label">Section</label>
															<select class="form-control" name="section" id="section" required>
															
															</select>
														</div>
														<div class="form-group col-12">
															<label class="col-form-label">Subject</label>
															<select class="form-control" name="subject" id="subject" required>
															</select>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="submit" class="btn green radius-xl outline" name="save">Save</button>
													<button type="button" class="btn red outline radius-xl" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</form>
								</div>
									</div>
								</div>
								<?php
								if (isset($_POST['save'])) {
									$semester = '';
									$year = $_POST['year'];
									$section = $_POST['section'];
									$subject = $_POST['subject'];
									$model->addFacultySubject($account_id, $semester, $section, $subject, $csid);
									echo "<script>;window.open('account-profile2?id=".$account_id."','_self');</script>";
								}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div class="ttr-overlay"></div>

		<script src="../dashboard/assets/js/jquery.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/popper.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-select/bootstrap-select.min.js"></script>
		<script src="../dashboard/assets/vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script>
		<script src="../dashboard/assets/vendors/magnific-popup/magnific-popup.js"></script>
		<script src="../dashboard/assets/vendors/counter/waypoints-min.js"></script>
		<script src="../dashboard/assets/vendors/counter/counterup.min.js"></script>
		<script src="../dashboard/assets/vendors/imagesloaded/imagesloaded.js"></script>
		<script src="../dashboard/assets/vendors/masonry/masonry.js"></script>
		<script src="../dashboard/assets/vendors/masonry/filter.js"></script>
		<script src="../dashboard/assets/vendors/owl-carousel/owl.carousel.js"></script>
		<script src='../dashboard/assets/vendors/scroll/scrollbar.min.js'></script>
		<script src="../dashboard/assets/js/functions.js"></script>
		<script src="../dashboard/assets/vendors/chart/chart.min.js"></script>
		<script src="../dashboard/assets/js/admin.js"></script>
		<script src='../dashboard/assets/vendors/calendar/moment.min.js'></script>	
		<script type="text/javascript">
			$(document).ready(function() {
				$('#course, #year').change(function() {
					var course = $('#course').val();
					var course_abv = $('#course').find(':selected').data('id');
					var semester = $('#semester').val();
					var year = $('#year').val();

					$.ajax({
						url: 'lib/fetch-sections.php',
						method: 'POST',
						data: {
							course : course,
							course_abv : course_abv,
							year : year
						},
						success:function(data) {
							$('#section').html(data);
							$('#section').selectpicker('refresh');
						}
					});

					$.ajax({
						url: 'lib/fetch-subjects.php',
						method: 'POST',
						data: {
							course : course,
							semester : semester,
							year : year
						},
						success:function(data) {
							$('#subject').html(data);
							$('#subject').selectpicker('refresh');
						}
					});
				});

				$('#table').DataTable();
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>
		<script type="text/javascript">
			function blockSpecialChar(evt) { 
				var charCode = (evt.which) ? evt.which : window.event.keyCode; 
				if (charCode <= 13) { 
					return true; 
				} 
				
				else { 
					var keyChar = String.fromCharCode(charCode); 
					var re = /^[A-Za-z. ]+$/ 
					return re.test(keyChar); 
				} 
			}
		</script>
	</body>

</html>