				<style type="text/css">
					.ttr-sidebar-navi ul li.show > a {
						background-color: #D6AE43!important;
					}

					.ttr-material-button:hover {
						background-color: #D6AE43!important;
					}

					.ttr-label, .ttr-icon > i {
						color: white;
					}
				</style>
				<nav class="ttr-sidebar-navi">
					<ul>
						<li style="padding-left: 20px; padding-top: 5px; padding-bottom: 5px; margin-top: 0px; margin-bottom: 0px;">
							<span class="ttr-label" style="color: #D5D6D8; font-weight: 500;">Menu</span>
						</li>
						<li class="<?php echo ($page == 'dashboard') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="index" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-home" aria-hidden="true"></i></span>
								<span class="ttr-label">Dashboard</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'faculty') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="faculty" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-user" aria-hidden="true"></i></span>
								<span class="ttr-label">Teachers</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'students') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="students" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-users" aria-hidden="true"></i></span>
								<span class="ttr-label">Students</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'subjects') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="manage-subjects" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-book" aria-hidden="true"></i></span>
								<span class="ttr-label">Subjects</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'school-year') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="semester" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
								<span class="ttr-label">School Year</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'sections') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="manage-sections" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-bookmark" aria-hidden="true"></i></span>
								<span class="ttr-label">Sections</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'questionnaires') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="questionares" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-question-circle" aria-hidden="true"></i></span>
								<span class="ttr-label">Questionnaires</span>
							</a>
						</li>
						<li class="<?php echo ($page == 'reports') ? "show" : ""; ?>" style="margin-top: 0px;">
							<a href="reports" class="ttr-material-button">
								<span class="ttr-icon"><i class="fa fa-bar-chart" aria-hidden="true"></i></span>
								<span class="ttr-label">Reports</span>
							</a>
						</li>
					</ul>
				</nav>