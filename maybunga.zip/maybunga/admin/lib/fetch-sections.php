<?php

	session_start();
	include('../../global/model.php');
	$model = new Model();

	$output = '';

	$rows = $model->displaySectionsSelection($_POST['year'], 1);

	if (!empty($rows)) {
		foreach ($rows as $row) {
			$output .= '<option value="'.$row['section_id'].'">'.$row['year'].'-'.$row['section_name'].'</option>';
		}
	}

	echo $output;

?>